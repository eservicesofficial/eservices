#!/usr/bin/env python3
"""Minimal process restarter - checks every 3 seconds"""
import subprocess
import time
import os
import socket

def is_port_listening(port):
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
            return s.connect_ex(('127.0.0.1', port)) == 0
    except:
        return False

def start_server():
    os.chdir('/home/z/my-project')
    env = {**os.environ, 'NODE_ENV': 'production', 'PORT': '3001', 'HOSTNAME': '0.0.0.0',
           'DATABASE_URL': 'file:/home/z/my-project/db/custom.db'}
    subprocess.Popen(
        ['node', '.next/standalone/server.js'],
        stdout=open('/dev/null', 'w'),
        stderr=open('/dev/null', 'w'),
        env=env
    )

def start_proxy():
    subprocess.Popen(
        ['python3', '/home/z/my-project/reverse_proxy.py'],
        stdout=open('/dev/null', 'w'),
        stderr=open('/dev/null', 'w'),
    )

count = 0
while True:
    count += 1
    if not is_port_listening(3001):
        start_server()
        print(f"[{count}] Restarted Next.js on 3001")
    if not is_port_listening(3000):
        start_proxy()
        print(f"[{count}] Restarted proxy on 3000")
    time.sleep(3)
