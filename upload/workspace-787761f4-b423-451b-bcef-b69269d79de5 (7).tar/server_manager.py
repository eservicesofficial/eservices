#!/usr/bin/env python3
"""
Production server manager:
- Runs Next.js production server on port 3001
- Runs Python reverse proxy on port 3000 -> 3001
- Auto-restarts both if they die
"""

import subprocess
import time
import os
import sys
import http.server
import http.client
import threading
import re

NEXTJS_PORT = 3001
PROXY_PORT = 3000

class ProxyHandler(http.server.BaseHTTPRequestHandler):
    """Reverse proxy: forwards requests from PROXY_PORT to NEXTJS_PORT"""
    
    def do_request(self, method):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length > 0 else None
        
        try:
            conn = http.client.HTTPConnection("127.0.0.1", NEXTJS_PORT, timeout=60)
            
            # Forward headers, skip hop-by-hop headers
            skip_headers = {'host', 'connection', 'transfer-encoding', 'keep-alive', 
                          'te', 'trailer', 'upgrade'}
            headers = {}
            for key in self.headers:
                if key.lower() not in skip_headers:
                    headers[key] = self.headers[key]
            headers['X-Forwarded-For'] = self.client_address[0]
            headers['X-Forwarded-Proto'] = 'http'
            
            conn.request(method, self.path, body=body, headers=headers)
            resp = conn.getresponse()
            
            self.send_response(resp.status)
            skip_resp = {'transfer-encoding', 'connection', 'keep-alive'}
            for key, val in resp.getheaders():
                if key.lower() not in skip_resp:
                    self.send_header(key, val)
            self.end_headers()
            
            # Stream response body
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()
            
            conn.close()
        except Exception as e:
            try:
                self.send_error(502, f"Proxy Error: {e}")
            except:
                pass
    
    def do_GET(self): self.do_request('GET')
    def do_POST(self): self.do_request('POST')
    def do_PUT(self): self.do_request('PUT')
    def do_DELETE(self): self.do_request('DELETE')
    def do_PATCH(self): self.do_request('PATCH')
    def do_OPTIONS(self): self.do_request('OPTIONS')
    def do_HEAD(self): self.do_request('HEAD')
    
    def log_message(self, format, *args):
        pass  # Suppress logs

def run_proxy():
    """Run reverse proxy on PROXY_PORT -> NEXTJS_PORT"""
    while True:
        try:
            server = http.server.HTTPServer(('0.0.0.0', PROXY_PORT), ProxyHandler)
            server.serve_forever()
        except OSError as e:
            if 'Address already in use' in str(e):
                time.sleep(1)
                continue
            print(f"[PROXY] Error: {e}", flush=True)
            time.sleep(3)
        except Exception as e:
            print(f"[PROXY] Error: {e}", flush=True)
            time.sleep(3)

def run_nextjs():
    """Run and manage the Next.js production server"""
    os.chdir('/home/z/my-project')
    
    while True:
        try:
            env = {**os.environ, 'NODE_ENV': 'production', 'PORT': str(NEXTJS_PORT), 'HOSTNAME': '0.0.0.0'}
            proc = subprocess.Popen(
                ['node', '.next/standalone/server.js'],
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=env,
            )
            print(f"[NEXT] Started: PID={proc.pid}", flush=True)
            
            for line in proc.stdout:
                decoded = line.decode('utf-8', errors='replace').rstrip()
                if decoded:
                    print(f"[NEXT] {decoded}", flush=True)
            
            ret = proc.wait()
            print(f"[NEXT] Exited: code={ret}, restarting in 3s...", flush=True)
            time.sleep(3)
        except Exception as e:
            print(f"[NEXT] Error: {e}", flush=True)
            time.sleep(3)

if __name__ == '__main__':
    os.chdir('/home/z/my-project')
    print(f"[MANAGER] Starting...", flush=True)
    print(f"[MANAGER] Next.js: port {NEXTJS_PORT}", flush=True)
    print(f"[MANAGER] Proxy: port {PROXY_PORT} -> {NEXTJS_PORT}", flush=True)
    
    # Start Next.js in daemon thread
    t = threading.Thread(target=run_nextjs, daemon=True)
    t.start()
    
    # Give Next.js time to start
    time.sleep(3)
    
    # Run proxy in main thread
    run_proxy()
