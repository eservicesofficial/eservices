import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSessionFromRequest, isAdmin } from '@/lib/auth';

// GET /api/auth/list-users - List users for admin switch-user feature
export async function GET(request: NextRequest) {
  try {
    const session = await getSessionFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    if (!isAdmin(session.role)) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 });
    }

    const users = await db.user.findMany({
      where: { unitCode: session.unitCode },
      select: {
        id: true,
        loginId: true,
        name: true,
        role: true,
        isActive: true,
      },
      orderBy: [{ role: 'asc' }, { name: 'asc' }],
    });

    return NextResponse.json(users);
  } catch (error) {
    console.error('List users for switch error:', error);
    return NextResponse.json({ error: 'Failed to list users' }, { status: 500 });
  }
}
