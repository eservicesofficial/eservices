import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSessionFromRequest } from '@/lib/auth';

// GET /api/auth/session - get fresh session with latest permissions from DB
export async function GET(request: NextRequest) {
  try {
    const session = await getSessionFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Read fresh user data from DB (not from JWT)
    const user = await db.user.findUnique({
      where: { id: session.userId },
      select: {
        id: true,
        loginId: true,
        name: true,
        role: true,
        permissions: true,
        isActive: true,
      },
    });

    if (!user || !user.isActive) {
      return NextResponse.json({ error: 'User not found or suspended' }, { status: 401 });
    }

    // Parse permissions from DB (fresh, not from JWT)
    let freshPermissions = {};
    try {
      freshPermissions = JSON.parse(user.permissions || '{}');
    } catch {
      freshPermissions = {};
    }

    return NextResponse.json({
      valid: true,
      user: {
        unitCode: session.unitCode,
        unitName: session.unitName,
        userId: user.id,
        loginId: user.loginId,
        name: user.name,
        role: user.role,
        permissions: freshPermissions,
      },
    });
  } catch (error) {
    console.error('Session refresh error:', error);
    return NextResponse.json({ error: 'Session refresh failed' }, { status: 500 });
  }
}
