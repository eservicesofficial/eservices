import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { getSessionFromRequest, isAdmin, createToken, logAction } from '@/lib/auth';

// POST /api/auth/switch-user - Admin switches to another user's account
export async function POST(request: NextRequest) {
  try {
    const session = await getSessionFromRequest(request);
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 });
    }

    // Only Admin can switch users
    if (!isAdmin(session.role)) {
      return NextResponse.json(
        { error: 'Access denied. Only Admin can switch users.' },
        { status: 403 }
      );
    }

    const body = await request.json();
    const { targetUserId } = body;

    if (!targetUserId) {
      return NextResponse.json(
        { error: 'Target user ID is required' },
        { status: 400 }
      );
    }

    // Find the target user
    const targetUser = await db.user.findFirst({
      where: { id: targetUserId, unitCode: session.unitCode },
    });

    if (!targetUser) {
      return NextResponse.json(
        { error: 'Target user not found in this unit' },
        { status: 404 }
      );
    }

    if (!targetUser.isActive) {
      return NextResponse.json(
        { error: 'Target user account is suspended' },
        { status: 403 }
      );
    }

    // Parse permissions for the target user
    let permissions = {};
    try {
      permissions = JSON.parse(targetUser.permissions || '{}');
    } catch {
      permissions = {};
    }

    // Find the unit for unitName
    const unit = await db.unit.findUnique({
      where: { code: session.unitCode },
    });
    const unitName = unit?.name || session.unitCode;

    // Create a new JWT for the target user
    const newSession = {
      unitCode: session.unitCode,
      unitName,
      userId: targetUser.id,
      loginId: targetUser.loginId,
      name: targetUser.name,
      role: targetUser.role,
      permissions,
    };

    const newToken = await createToken(newSession);

    // Log the switch action
    await logAction(
      session.unitCode,
      session.userId,
      session.name,
      session.role,
      'SWITCH_USER',
      targetUser.name,
      {
        targetLoginId: targetUser.loginId,
        targetRole: targetUser.role,
        switchedTo: targetUser.name,
      },
      request
    );

    return NextResponse.json({
      success: true,
      message: `Switched to ${targetUser.name}'s account`,
      token: newToken,
      user: {
        unitCode: session.unitCode,
        unitName,
        userId: targetUser.id,
        loginId: targetUser.loginId,
        name: targetUser.name,
        role: targetUser.role,
        permissions,
      },
    });
  } catch (error) {
    console.error('Switch user error:', error);
    const message = error instanceof Error ? error.message : 'Unknown error';
    return NextResponse.json({ error: `Failed to switch user: ${message}` }, { status: 500 });
  }
}
