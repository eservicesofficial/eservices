import { NextRequest, NextResponse } from 'next/server';
import { db } from '@/lib/db';
import { createToken, verifyToken, verifyPassword, logAction } from '@/lib/auth';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { unitCode, loginId, password } = body;

    if (!unitCode || !loginId || !password) {
      return NextResponse.json(
        { error: 'Unit Code, User ID, and Password are required' },
        { status: 400 }
      );
    }

    // Find the unit
    const unit = await db.unit.findUnique({
      where: { code: unitCode.toUpperCase().trim() },
    });

    if (!unit) {
      return NextResponse.json(
        { error: 'Invalid Unit Code. No business found with this code.' },
        { status: 401 }
      );
    }

    if (!unit.isActive) {
      return NextResponse.json(
        { error: 'This unit is currently deactivated. Contact support.' },
        { status: 403 }
      );
    }

    // Find the user within this unit
    const user = await db.user.findUnique({
      where: {
        unitCode_loginId: {
          unitCode: unit.code,
          loginId: loginId.trim().toLowerCase(),
        },
      },
    });

    if (!user) {
      return NextResponse.json(
        { error: 'Invalid User ID or Password' },
        { status: 401 }
      );
    }

    if (!user.isActive) {
      return NextResponse.json(
        { error: 'Your account has been suspended. Contact your administrator.' },
        { status: 403 }
      );
    }

    // Verify password
    const valid = await verifyPassword(password, user.password);
    if (!valid) {
      return NextResponse.json(
        { error: 'Invalid User ID or Password' },
        { status: 401 }
      );
    }

    // Update last login
    await db.user.update({
      where: { id: user.id },
      data: { lastLogin: new Date() },
    });

    // Parse permissions
    let permissions = {};
    try {
      permissions = JSON.parse(user.permissions || '{}');
    } catch {
      permissions = {};
    }

    // Create JWT token
    const session = {
      unitCode: unit.code,
      unitName: unit.name,
      userId: user.id,
      loginId: user.loginId,
      name: user.name,
      role: user.role,
      permissions,
    };

    const token = await createToken(session);

    // Log the login action
    await logAction(
      unit.code,
      user.id,
      user.name,
      user.role,
      'LOGIN',
      `Unit: ${unit.name}`,
      { loginId: user.loginId },
      request
    );

    return NextResponse.json({
      success: true,
      message: 'Login successful',
      token,
      user: {
        unitCode: unit.code,
        unitName: unit.name,
        userId: user.id,
        loginId: user.loginId,
        name: user.name,
        role: user.role,
        permissions,
      },
    });
  } catch (error) {
    console.error('Auth error:', error);
    return NextResponse.json(
      { error: 'Authentication failed' },
      { status: 500 }
    );
  }
}

// GET /api/auth - validate session token
export async function GET(request: NextRequest) {
  try {
    const authHeader = request.headers.get('authorization');
    if (!authHeader?.startsWith('Bearer ')) {
      return NextResponse.json({ error: 'No token provided' }, { status: 401 });
    }

    const token = authHeader.slice(7);
    const session = await verifyToken(token);

    if (!session) {
      return NextResponse.json({ error: 'Invalid or expired token' }, { status: 401 });
    }

    // Check if user still exists and is active
    const user = await db.user.findUnique({
      where: { id: session.userId },
    });

    if (!user || !user.isActive) {
      return NextResponse.json({ error: 'User account not found or suspended' }, { status: 401 });
    }

    // Check if unit is still active
    const unit = await db.unit.findUnique({
      where: { code: session.unitCode },
    });

    if (!unit || !unit.isActive) {
      return NextResponse.json({ error: 'Unit not found or deactivated' }, { status: 401 });
    }

    return NextResponse.json({ valid: true, user: session });
  } catch (error) {
    console.error('Session validation error:', error);
    return NextResponse.json({ error: 'Session validation failed' }, { status: 500 });
  }
}
