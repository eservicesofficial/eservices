import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionFromRequest, logAction, isAdmin } from '@/lib/auth'

export async function POST(request: NextRequest) {
  try {
    const session = await getSessionFromRequest(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    if (!isAdmin(session.role)) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    await logAction(session.unitCode, session.userId, session.name, session.role, 'RESET_DATA', '', {}, request)

    // Only delete data belonging to the current unit
    await db.$transaction([
      db.refund.deleteMany({ where: { unitCode: session.unitCode } }),
      db.invoiceItem.deleteMany({ where: { invoice: { unitCode: session.unitCode } } }),
      db.invoice.deleteMany({ where: { unitCode: session.unitCode } }),
      db.attendance.deleteMany({ where: { profile: { unitCode: session.unitCode } } }),
      db.staffProfile.deleteMany({ where: { unitCode: session.unitCode } }),
      db.khataTransaction.deleteMany({ where: { profile: { unitCode: session.unitCode } } }),
      db.khataProfile.deleteMany({ where: { unitCode: session.unitCode } }),
      db.pettyCashTransaction.deleteMany({ where: { unitCode: session.unitCode } }),
      db.pettyCashConfig.deleteMany({ where: { id: session.unitCode } }),
      db.item.deleteMany({ where: { unitCode: session.unitCode } }),
      db.category.deleteMany({ where: { unitCode: session.unitCode } }),
      db.calcHistory.deleteMany({ where: { unitCode: session.unitCode } }),
      db.settings.deleteMany({ where: { unitCode: session.unitCode } }),
    ])
    return NextResponse.json({ success: true, message: 'All data cleared' })
  } catch (error) {
    console.error('Error resetting data:', error)
    return NextResponse.json({ error: 'Failed to reset data' }, { status: 500 })
  }
}
