import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionFromRequest, logAction, sessionHasPermission } from '@/lib/auth'

export async function GET(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSessionFromRequest(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    const { id } = await params
    const invoice = await db.invoice.findUnique({
      where: { id },
      include: { invoiceItems: true, refunds: true },
    })
    if (!invoice || invoice.unitCode !== session.unitCode) {
      return NextResponse.json({ error: 'Invoice not found' }, { status: 404 })
    }
    return NextResponse.json(invoice)
  } catch (error) {
    console.error('Error fetching invoice:', error)
    return NextResponse.json({ error: 'Failed to fetch invoice' }, { status: 500 })
  }
}

export async function PUT(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSessionFromRequest(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    if (!sessionHasPermission(session, 'billing', 'edit')) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    const { id } = await params
    const body = await request.json()
    const { invoiceItems, refunds: _refunds, isCompleted: _isCompleted, id: _id, createdAt: _createdAt, updatedAt: _updatedAt, ...invoiceData } = body

    // Verify invoice belongs to this unit
    const existing = await db.invoice.findUnique({ where: { id } })
    if (!existing || existing.unitCode !== session.unitCode) {
      return NextResponse.json({ error: 'Invoice not found' }, { status: 404 })
    }

    const invoice = await db.$transaction(async (tx) => {
      // Only delete/recreate items if invoiceItems are provided
      if (Array.isArray(invoiceItems)) {
        await tx.invoiceItem.deleteMany({ where: { invoiceId: id } })
      }

      return tx.invoice.update({
        where: { id },
        data: {
          ...invoiceData,
          ...(Array.isArray(invoiceItems) && invoiceItems.length > 0
            ? {
                invoiceItems: {
                  create: invoiceItems.map((item: any) => ({
                    name: String(item.name || ''),
                    description: String(item.description || ''),
                    qty: parseInt(String(item.qty)) || 0,
                    rate: parseFloat(String(item.rate)) || 0,
                    total: parseFloat(String(item.total)) || 0,
                  })),
                },
              }
            : {}),
        },
        include: { invoiceItems: true },
      })
    })

    await logAction(session.unitCode, session.userId, session.name, session.role, 'UPDATE_INVOICE', existing.invoiceNumber, { invoiceId: id }, request)

    return NextResponse.json(invoice)
  } catch (error) {
    console.error('Error updating invoice:', error)
    return NextResponse.json({ error: 'Failed to update invoice' }, { status: 500 })
  }
}

export async function DELETE(
  request: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const session = await getSessionFromRequest(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    if (!sessionHasPermission(session, 'billing', 'delete')) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    const { id } = await params

    // Verify invoice belongs to this unit
    const existing = await db.invoice.findUnique({ where: { id } })
    if (!existing || existing.unitCode !== session.unitCode) {
      return NextResponse.json({ error: 'Invoice not found' }, { status: 404 })
    }

    await logAction(session.unitCode, session.userId, session.name, session.role, 'DELETE_INVOICE', existing.invoiceNumber, { invoiceId: id }, request)

    // Delete refunds first (FK constraint), then invoice (cascade deletes invoiceItems)
    await db.$transaction([
      db.refund.deleteMany({ where: { originalInvoiceId: id } }),
      db.invoice.delete({ where: { id } }),
    ])
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error('Error deleting invoice:', error)
    return NextResponse.json({ error: 'Failed to delete invoice' }, { status: 500 })
  }
}
