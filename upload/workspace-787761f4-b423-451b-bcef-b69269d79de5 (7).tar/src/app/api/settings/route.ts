import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { getSessionFromRequest, logAction, sessionHasPermission } from '@/lib/auth'

export async function GET(request: NextRequest) {
  try {
    const session = await getSessionFromRequest(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }

    let settings = await db.settings.findUnique({ where: { unitCode: session.unitCode } })
    if (!settings) {
      settings = await db.settings.create({ data: { unitCode: session.unitCode } })
    }
    return NextResponse.json(settings)
  } catch (error) {
    console.error('Error fetching settings:', error)
    return NextResponse.json({ error: 'Failed to fetch settings' }, { status: 500 })
  }
}

export async function PUT(request: NextRequest) {
  try {
    const session = await getSessionFromRequest(request)
    if (!session) {
      return NextResponse.json({ error: 'Unauthorized' }, { status: 401 })
    }
    if (!sessionHasPermission(session, 'settings', 'edit')) {
      return NextResponse.json({ error: 'Access denied' }, { status: 403 })
    }

    const body = await request.json()
    const { section: _section, ...dbFields } = body
    const cleanFields: Record<string, unknown> = {}
    for (const [key, value] of Object.entries(dbFields)) {
      if (value !== undefined && value !== null) {
        cleanFields[key] = value
      }
    }

    const settings = await db.settings.upsert({
      where: { unitCode: session.unitCode },
      update: cleanFields,
      create: { unitCode: session.unitCode, ...cleanFields },
    })

    // Log settings change
    if (session) {
      await logAction(
        session.unitCode,
        session.userId,
        session.name,
        session.role,
        'UPDATE_SETTINGS',
        _section || 'General',
        { fields: Object.keys(cleanFields) },
        request
      )
    }

    return NextResponse.json(settings)
  } catch (error) {
    console.error('Error updating settings:', error)
    return NextResponse.json({ error: 'Failed to update settings' }, { status: 500 })
  }
}
