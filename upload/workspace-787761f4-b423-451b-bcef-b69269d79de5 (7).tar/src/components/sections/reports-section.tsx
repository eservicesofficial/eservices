'use client';

import React, { useState, useEffect, useCallback, useMemo } from 'react';
import {
  FileText,
  Wallet,
  Users,
  BookOpen,
  Download,
  Filter,
  RotateCcw,
  Loader2,
  TrendingUp,
  TrendingDown,
  IndianRupee,
  CalendarDays,
  UserCheck,
  UserX,
  Clock,
  ArrowUpRight,
  ArrowDownRight,
  BarChart3,
  TrendingDownIcon,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
  CardDescription,
} from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import {
  Tabs,
  TabsContent,
  TabsList,
  TabsTrigger,
} from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';

// --- Types ---
interface InvoiceReport {
  invoiceNo: string;
  date: string;
  customerName: string;
  paymentMethod: string;
  amount: number;
  status: string;
}

interface CashReport {
  pettyCash: number;
  totalIncome: number;
  totalExpense: number;
  balance: number;
  transactions: {
    id: string;
    date: string;
    description: string;
    type: 'income' | 'expense';
    amount: number;
  }[];
}

interface AttendanceReport {
  totalStaff: number;
  presentToday: number;
  absentToday: number;
  onLeave: number;
  staffList: {
    id: string;
    name: string;
    designation: string;
    status: 'present' | 'absent' | 'on-leave';
    checkIn?: string;
    checkOut?: string;
  }[];
}

interface KhataReport {
  totalReceivable: number;
  totalPayable: number;
  netPosition: number;
  profiles: {
    id: string;
    name: string;
    type: 'receivable' | 'payable';
    balance: number;
  }[];
}

interface CsvColumn {
  key: string;
  label: string;
}

// eslint-disable-next-line @typescript-eslint/no-empty-object-type
interface ReportsSectionProps {}

// --- Helpers ---
function formatCurrency(amount: number): string {
  return `₹${amount.toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

function getTodayFilename(prefix: string): string {
  const today = new Date().toISOString().split('T')[0];
  return `${prefix}_${today}.csv`;
}

function exportToCSV<T extends Record<string, unknown>>(
  data: T[],
  filename: string,
  columns: CsvColumn[]
) {
  if (data.length === 0) return;

  const escapeCSV = (value: unknown): string => {
    const str = String(value ?? '');
    if (str.includes('"') || str.includes(',') || str.includes('\n')) {
      return `"${str.replace(/"/g, '""')}"`;
    }
    return str;
  };

  const header = columns.map((c) => escapeCSV(c.label)).join(',');
  const rows = data.map((row) =>
    columns.map((c) => escapeCSV(row[c.key])).join(',')
  );
  const csv = [header, ...rows].join('\n');

  const blob = new Blob(['\uFEFF' + csv], { type: 'text/csv;charset=utf-8;' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

const paymentMethods = ['All', 'Cash', 'Card', 'UPI', 'Net Banking', 'Replace', 'Refund'];

// --- Component ---
export default function ReportsSection(_props: ReportsSectionProps) {
  // Track when reports were last fetched
  const [lastFetched, setLastFetched] = useState<string>('');

  // === Invoice Report State ===
  const [invoiceData, setInvoiceData] = useState<InvoiceReport[]>([]);
  const [invoiceSummary, setInvoiceSummary] = useState({
    totalRevenue: 0,
    codAmount: 0,
    onlineAmount: 0,
    totalOrders: 0,
  });
  const [invoiceLoading, setInvoiceLoading] = useState(false);
  const [startDate, setStartDate] = useState(() => {
    const d = new Date();
    d.setDate(1);
    return d.toISOString().split('T')[0];
  });
  const [endDate, setEndDate] = useState(() => new Date().toISOString().split('T')[0]);
  const [paymentFilter, setPaymentFilter] = useState('All');
  const [customerFilter, setCustomerFilter] = useState('');

  // === Cash Report State ===
  const [cashReport, setCashReport] = useState<CashReport | null>(null);
  const [cashLoading, setCashLoading] = useState(false);

  // === Attendance Report State ===
  const [attendanceReport, setAttendanceReport] = useState<AttendanceReport | null>(null);
  const [attendanceLoading, setAttendanceLoading] = useState(false);

  // === Khata Report State ===
  const [khataReport, setKhataReport] = useState<KhataReport | null>(null);
  const [khataLoading, setKhataLoading] = useState(false);

  // === Computed Chart Data ===
  // Invoice: daily revenue breakdown
  const dailyRevenueData = useMemo(() => {
    const grouped: Record<string, number> = {};
    invoiceData.forEach((inv) => {
      const dateLabel = inv.date;
      grouped[dateLabel] = (grouped[dateLabel] || 0) + inv.amount;
    });
    return Object.entries(grouped)
      .map(([date, revenue]) => {
        // Shorten date label: "2025-01-15" -> "Jan 15"
        const d = new Date(date + 'T00:00:00');
        const label = d.toLocaleDateString('en-IN', { month: 'short', day: 'numeric' });
        return { date: label, revenue: Math.round(revenue * 100) / 100 };
      })
      .sort((a, b) => a.date.localeCompare(b.date));
  }, [invoiceData]);

  // Invoice: CSS bar chart data (top 10 daily revenue sorted desc)
  const cssRevenueBars = useMemo(() => {
    if (dailyRevenueData.length === 0) return [];
    const maxRev = Math.max(...dailyRevenueData.map((d) => d.revenue));
    return dailyRevenueData
      .slice()
      .sort((a, b) => b.revenue - a.revenue)
      .slice(0, 10)
      .map((d) => ({
        label: d.date,
        value: d.revenue,
        widthPct: maxRev > 0 ? Math.round((d.revenue / maxRev) * 100) : 0,
      }));
  }, [dailyRevenueData]);

  // Cash: income vs expense pie data
  const cashPieData = useMemo(() => {
    if (!cashReport) return [];
    return [
      { name: 'Income', value: cashReport.totalIncome },
      { name: 'Expense', value: cashReport.totalExpense },
    ].filter((d) => d.value > 0);
  }, [cashReport]);

  // Cash: CSS comparison bars
  const cashFlowComparison = useMemo(() => {
    if (!cashReport) return null;
    const total = cashReport.totalIncome + cashReport.totalExpense;
    return {
      income: cashReport.totalIncome,
      expense: cashReport.totalExpense,
      incomePct: total > 0 ? Math.round((cashReport.totalIncome / total) * 100) : 50,
      expensePct: total > 0 ? Math.round((cashReport.totalExpense / total) * 100) : 50,
      total,
    };
  }, [cashReport]);

  const CASH_PIE_COLORS = ['#10b981', '#ef4444']; // emerald-500, red-500

  // Attendance: ratio
  const attendanceRatio = useMemo(() => {
    if (!attendanceReport || attendanceReport.totalStaff === 0) return 0;
    return Math.round((attendanceReport.presentToday / attendanceReport.totalStaff) * 100);
  }, [attendanceReport]);

  // Khata: top profiles (sorted by balance desc, top 10)
  const khataTopProfiles = useMemo(() => {
    if (!khataReport) return { receivable: [], payable: [] };
    const sorted = [...khataReport.profiles].sort((a, b) => Math.abs(b.balance) - Math.abs(a.balance));
    return {
      receivable: sorted
        .filter((p) => p.type === 'receivable')
        .slice(0, 8)
        .map((p) => ({ name: p.name, balance: p.balance, fill: '#10b981' })),
      payable: sorted
        .filter((p) => p.type === 'payable')
        .slice(0, 8)
        .map((p) => ({ name: p.name, balance: p.balance, fill: '#ef4444' })),
    };
  }, [khataReport]);

  // --- Fetch Invoice Reports ---
  const fetchInvoiceReports = useCallback(async () => {
    setInvoiceLoading(true);
    try {
      const params = new URLSearchParams({ startDate, endDate });
      if (paymentFilter !== 'All') params.set('paymentMethod', paymentFilter);
      if (customerFilter.trim()) params.set('customerName', customerFilter.trim());

      const res = await fetch(`/api/reports/invoices?${params}`);
      if (res.ok) {
        const data = await res.json();
        setInvoiceData(data.transactions || []);
        setInvoiceSummary({
          totalRevenue: data.totalRevenue || 0,
          codAmount: data.codAmount || 0,
          onlineAmount: data.onlineAmount || 0,
          totalOrders: data.totalOrders || 0,
        });
      }
    } catch {
      toast.error('Failed to fetch invoice reports');
    } finally {
      setInvoiceLoading(false);
      setLastFetched(new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit', second: '2-digit' }));
    }
  }, [startDate, endDate, paymentFilter, customerFilter]);

  useEffect(() => {
    fetchInvoiceReports();
  }, [fetchInvoiceReports]);

  // --- Fetch Cash Reports ---
  const fetchCashReports = useCallback(async () => {
    setCashLoading(true);
    try {
      const res = await fetch(`/api/reports/cash?startDate=${startDate}&endDate=${endDate}`);
      if (res.ok) {
        const data = await res.json();
        setCashReport(data);
      }
    } catch {
      toast.error('Failed to fetch cash reports');
    } finally {
      setCashLoading(false);
    }
  }, [startDate, endDate]);

  // --- Fetch Attendance Reports ---
  const fetchAttendanceReports = useCallback(async () => {
    setAttendanceLoading(true);
    try {
      const res = await fetch('/api/reports/attendance');
      if (res.ok) {
        const data = await res.json();
        setAttendanceReport(data);
      }
    } catch {
      toast.error('Failed to fetch attendance reports');
    } finally {
      setAttendanceLoading(false);
    }
  }, []);

  // --- Fetch Khata Reports ---
  const fetchKhataReports = useCallback(async () => {
    setKhataLoading(true);
    try {
      const res = await fetch('/api/reports/khata');
      if (res.ok) {
        const data = await res.json();
        setKhataReport(data);
      }
    } catch {
      toast.error('Failed to fetch khata reports');
    } finally {
      setKhataLoading(false);
    }
  }, []);

  // --- Invoice Filter Handlers ---
  const handleApplyFilters = () => {
    fetchInvoiceReports();
    fetchCashReports();
  };

  const handleResetFilters = () => {
    const d = new Date();
    d.setDate(1);
    setStartDate(d.toISOString().split('T')[0]);
    setEndDate(new Date().toISOString().split('T')[0]);
    setPaymentFilter('All');
    setCustomerFilter('');
  };

  // --- Download Invoice CSV ---
  const handleDownloadInvoiceCSV = () => {
    if (invoiceData.length === 0) {
      toast.info('No invoice data to download');
      return;
    }
    const columns: CsvColumn[] = [
      { key: 'invoiceNo', label: 'Invoice No' },
      { key: 'date', label: 'Date' },
      { key: 'customerName', label: 'Customer' },
      { key: 'paymentMethod', label: 'Payment Method' },
      { key: 'amount', label: 'Amount' },
      { key: 'status', label: 'Status' },
    ];
    exportToCSV(invoiceData as unknown as Record<string, unknown>[], getTodayFilename('invoice-report'), columns);
    toast.success('Invoice report exported');
  };

  // --- Download Cash CSV ---
  const handleDownloadCashCSV = () => {
    if (!cashReport || cashReport.transactions.length === 0) {
      toast.info('No cash data to download');
      return;
    }
    const columns: CsvColumn[] = [
      { key: 'date', label: 'Date' },
      { key: 'description', label: 'Description' },
      { key: 'type', label: 'Type' },
      { key: 'amount', label: 'Amount' },
    ];
    exportToCSV(
      cashReport.transactions as unknown as Record<string, unknown>[],
      getTodayFilename('cash-report'),
      columns
    );
    toast.success('Cash report exported');
  };

  // --- Download Attendance CSV ---
  const handleDownloadAttendanceCSV = () => {
    if (!attendanceReport || attendanceReport.staffList.length === 0) {
      toast.info('No attendance data to download');
      return;
    }
    const columns: CsvColumn[] = [
      { key: 'name', label: 'Name' },
      { key: 'designation', label: 'Designation' },
      { key: 'status', label: 'Status' },
      { key: 'checkIn', label: 'Check In' },
      { key: 'checkOut', label: 'Check Out' },
    ];
    exportToCSV(
      attendanceReport.staffList as unknown as Record<string, unknown>[],
      getTodayFilename('attendance-report'),
      columns
    );
    toast.success('Attendance report exported');
  };

  // --- Download Khata CSV ---
  const handleDownloadKhataCSV = () => {
    if (!khataReport || khataReport.profiles.length === 0) {
      toast.info('No khata data to download');
      return;
    }
    const columns: CsvColumn[] = [
      { key: 'name', label: 'Name' },
      { key: 'type', label: 'Type' },
      { key: 'balance', label: 'Balance' },
    ];
    exportToCSV(
      khataReport.profiles as unknown as Record<string, unknown>[],
      getTodayFilename('khata-report'),
      columns
    );
    toast.success('Khata report exported');
  };

  // --- Payment Method Status Variant ---
  const getStatusVariant = (status: string) => {
    switch (status.toLowerCase()) {
      case 'paid':
      case 'completed':
        return 'default';
      case 'pending':
        return 'secondary';
      case 'refunded':
      case 'cancelled':
        return 'destructive';
      default:
        return 'outline';
    }
  };

  return (
    <div className="space-y-6">
      {/* ── Gradient Header Banner ── */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 p-5 md:p-6 text-white shadow-lg shadow-green-600/20">
        {/* Background decoration */}
        <div className="pointer-events-none absolute -right-8 -top-8 size-36 rounded-full bg-white/10" />
        <div className="pointer-events-none absolute -bottom-6 -left-6 size-28 rounded-full bg-white/5" />
        <div className="pointer-events-none absolute right-24 top-2 size-14 rounded-full bg-white/5" />

        <div className="relative z-10 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3">
          <div>
            <h2 className="text-xl md:text-2xl font-bold tracking-tight flex items-center gap-2">
              <BarChart3 className="size-6" />
              Reports &amp; Analytics
            </h2>
            <p className="text-green-100 text-sm mt-1">
              Comprehensive reports across invoices, cash, attendance, and khata
            </p>
          </div>
          {lastFetched && (
            <div className="flex items-center gap-1.5 rounded-lg bg-white/15 backdrop-blur-sm px-3 py-1.5 text-xs">
              <Clock className="size-3" />
              <span className="text-green-100">Updated</span>
              <span className="font-medium">{lastFetched}</span>
            </div>
          )}
        </div>
      </div>

      <Card>
        <CardContent className="pt-6">
          {/* Date Range Filters (shared across tabs) */}
          <Card className="mb-4 bg-muted/30 border-0">
            <CardContent className="p-4">
              <div className="flex flex-col gap-3 sm:flex-row sm:items-end sm:flex-wrap">
            <div className="grid gap-1.5">
              <Label className="text-xs text-muted-foreground">Start Date</Label>
              <div className="relative">
                <CalendarDays className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                <Input
                  type="date"
                  value={startDate}
                  onChange={(e) => setStartDate(e.target.value)}
                  className="w-full sm:w-[160px] pl-9 focus-visible:ring-2 focus-visible:ring-green-500/20 focus-visible:border-green-500 transition-all duration-200"
                />
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs text-muted-foreground">End Date</Label>
              <div className="relative">
                <CalendarDays className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
                <Input
                  type="date"
                  value={endDate}
                  onChange={(e) => setEndDate(e.target.value)}
                  className="w-full sm:w-[160px] pl-9 focus-visible:ring-2 focus-visible:ring-green-500/20 focus-visible:border-green-500 transition-all duration-200"
                />
              </div>
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs text-muted-foreground">Payment Method</Label>
              <Select value={paymentFilter} onValueChange={setPaymentFilter}>
                <SelectTrigger className="w-full sm:w-[160px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {paymentMethods.map((m) => (
                    <SelectItem key={m} value={m}>
                      {m}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label className="text-xs text-muted-foreground">Customer Name</Label>
              <Input
                placeholder="Search..."
                value={customerFilter}
                onChange={(e) => setCustomerFilter(e.target.value)}
                className="w-full sm:w-[180px]"
              />
            </div>
            <div className="flex gap-2">
              <Button
                onClick={handleApplyFilters}
                className="bg-green-600 hover:bg-green-700 text-white gap-1.5 hover-glow-green"
              >
                <Filter className="h-4 w-4" />
                Apply
              </Button>
              <Button variant="outline" onClick={handleResetFilters} className="gap-1.5">
                <RotateCcw className="h-4 w-4" />
                Reset
              </Button>
            </div>
              </div>
            </CardContent>
          </Card>

          <Tabs defaultValue="invoices">
            <TabsList className="mb-4 flex-wrap h-auto gap-1">
              <TabsTrigger value="invoices" className="gap-1.5">
                <FileText className="h-4 w-4" />
                Invoices
              </TabsTrigger>
              <TabsTrigger value="cash" className="gap-1.5">
                <Wallet className="h-4 w-4" />
                Cash
              </TabsTrigger>
              <TabsTrigger value="attendance" className="gap-1.5">
                <Users className="h-4 w-4" />
                Attendance
              </TabsTrigger>
              <TabsTrigger value="khata" className="gap-1.5">
                <BookOpen className="h-4 w-4" />
                Khata
              </TabsTrigger>
            </TabsList>

            {/* ========== INVOICE REPORTS TAB ========== */}
            <TabsContent value="invoices">
              {/* Quick Glance Stats Row */}
              {!invoiceLoading && (
                <div className="mb-4 grid gap-3 grid-cols-2 lg:grid-cols-4">
                  <Card className="py-4 card-hover-glow border-l-4 border-l-green-500">
                    <CardContent className="flex items-center gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                        <FileText className="h-5 w-5 text-green-600" />
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Total Invoices</p>
                        <p className="text-lg font-bold tabular-nums">{invoiceData.length}</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="py-4 card-hover-glow border-l-4 border-l-emerald-500">
                    <CardContent className="flex items-center gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-100 dark:bg-emerald-900/30">
                        <TrendingUp className="h-5 w-5 text-emerald-600" />
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Total Revenue</p>
                        <p className="text-lg font-bold tabular-nums">{formatCurrency(invoiceSummary.totalRevenue)}</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="py-4 card-hover-glow border-l-4 border-l-teal-500">
                    <CardContent className="flex items-center gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-teal-100 dark:bg-teal-900/30">
                        <BarChart3 className="h-5 w-5 text-teal-600" />
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Avg Bill Value</p>
                        <p className="text-lg font-bold tabular-nums">{invoiceData.length > 0 ? formatCurrency(invoiceSummary.totalRevenue / invoiceData.length) : '₹0.00'}</p>
                      </div>
                    </CardContent>
                  </Card>
                  <Card className="py-4 card-hover-glow border-l-4 border-l-amber-500">
                    <CardContent className="flex items-center gap-3">
                      <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/30">
                        <Clock className="h-5 w-5 text-amber-600" />
                      </div>
                      <div>
                        <p className="text-[10px] text-muted-foreground uppercase tracking-wider">Pending Bills</p>
                        <p className="text-lg font-bold tabular-nums">{invoiceData.filter((inv) => inv.status.toLowerCase() === 'pending' || inv.status.toLowerCase() === 'partial').length}</p>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              )}

              {/* Payment Aging Summary */}
              {!invoiceLoading && invoiceData.length > 0 && (
                (() => {
                  const pending = invoiceData.filter((inv) => inv.status.toLowerCase() === 'pending' || inv.status.toLowerCase() === 'partial');
                  const paid = invoiceData.filter((inv) => inv.status.toLowerCase() === 'paid' || inv.status.toLowerCase() === 'completed');
                  const cancelled = invoiceData.filter((inv) => inv.status.toLowerCase() === 'cancelled' || inv.status.toLowerCase() === 'refunded');

                  return (
                    <div className="mb-4">
                      <p className="text-xs text-muted-foreground font-medium mb-2 flex items-center gap-1.5">
                        <Clock className="size-3.5" />
                        Payment Aging Summary
                      </p>
                      <div className="grid gap-3 grid-cols-3">
                        <Card className="py-4 border-l-4 border-l-amber-500 card-hover-glow">
                          <CardContent className="flex flex-col items-center gap-1 text-center">
                            <div className="flex size-8 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/30">
                              <Clock className="size-4 text-amber-600" />
                            </div>
                            <p className="text-2xl font-bold tabular-nums text-amber-700 dark:text-amber-400">{pending.length}</p>
                            <p className="text-xs text-muted-foreground font-medium">Pending</p>
                            <p className="text-xs font-semibold text-foreground tabular-nums">
                              {formatCurrency(pending.reduce((s, inv) => s + inv.amount, 0))}
                            </p>
                          </CardContent>
                        </Card>
                        <Card className="py-4 border-l-4 border-l-green-500 card-hover-glow">
                          <CardContent className="flex flex-col items-center gap-1 text-center">
                            <div className="flex size-8 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                              <UserCheck className="size-4 text-green-600" />
                            </div>
                            <p className="text-2xl font-bold tabular-nums text-green-700 dark:text-green-400">{paid.length}</p>
                            <p className="text-xs text-muted-foreground font-medium">Paid</p>
                            <p className="text-xs font-semibold text-foreground tabular-nums">
                              {formatCurrency(paid.reduce((s, inv) => s + inv.amount, 0))}
                            </p>
                          </CardContent>
                        </Card>
                        <Card className="py-4 border-l-4 border-l-red-500 card-hover-glow">
                          <CardContent className="flex flex-col items-center gap-1 text-center">
                            <div className="flex size-8 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/30">
                              <UserX className="size-4 text-red-600" />
                            </div>
                            <p className="text-2xl font-bold tabular-nums text-red-700 dark:text-red-400">{cancelled.length}</p>
                            <p className="text-xs text-muted-foreground font-medium">Cancelled</p>
                            <p className="text-xs font-semibold text-foreground tabular-nums">
                              {formatCurrency(cancelled.reduce((s, inv) => s + inv.amount, 0))}
                            </p>
                          </CardContent>
                        </Card>
                      </div>
                    </div>
                  );
                })()
              )}

              {/* Summary Cards */}
              <div className="mb-4 grid gap-3 grid-cols-2 lg:grid-cols-4">
                <Card className="py-4 card-hover-glow">
                  <CardContent className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                      <IndianRupee className="h-5 w-5 text-green-600" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Total Revenue</p>
                      {invoiceLoading ? (
                        <Skeleton className="h-5 w-24 mt-1" />
                      ) : (
                        <p className="text-lg font-bold">{formatCurrency(invoiceSummary.totalRevenue)}</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card className="py-4 card-hover-glow">
                  <CardContent className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/30">
                      <Wallet className="h-5 w-5 text-amber-600" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">COD Amount</p>
                      {invoiceLoading ? (
                        <Skeleton className="h-5 w-24 mt-1" />
                      ) : (
                        <p className="text-lg font-bold">{formatCurrency(invoiceSummary.codAmount)}</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card className="py-4 card-hover-glow">
                  <CardContent className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-sky-100 dark:bg-sky-900/30">
                      <TrendingUp className="h-5 w-5 text-sky-600" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Online Amount</p>
                      {invoiceLoading ? (
                        <Skeleton className="h-5 w-24 mt-1" />
                      ) : (
                        <p className="text-lg font-bold">{formatCurrency(invoiceSummary.onlineAmount)}</p>
                      )}
                    </div>
                  </CardContent>
                </Card>

                <Card className="py-4 card-hover-glow">
                  <CardContent className="flex items-center gap-3">
                    <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-purple-100 dark:bg-purple-900/30">
                      <CalendarDays className="h-5 w-5 text-purple-600" />
                    </div>
                    <div>
                      <p className="text-xs text-muted-foreground">Total Orders</p>
                      {invoiceLoading ? (
                        <Skeleton className="h-5 w-24 mt-1" />
                      ) : (
                        <p className="text-lg font-bold">{invoiceSummary.totalOrders}</p>
                      )}
                    </div>
                  </CardContent>
                </Card>
              </div>

              {/* Daily Revenue Chart (recharts) */}
              {dailyRevenueData.length > 0 && !invoiceLoading && (
                <Card className="mb-4">
                  <CardHeader className="pb-2 pt-4 px-5">
                    <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                      <BarChart3 className="h-4 w-4 text-green-600" />
                      Daily Revenue Breakdown
                    </CardTitle>
                  </CardHeader>
                  <CardContent className="px-5 pb-4">
                    <div className="h-64">
                      <ResponsiveContainer width="100%" height="100%">
                        <BarChart data={dailyRevenueData} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                          <XAxis
                            dataKey="date"
                            tick={{ fontSize: 11, fill: '#6b7280' }}
                            axisLine={{ stroke: '#e5e7eb' }}
                            tickLine={false}
                          />
                          <YAxis
                            tick={{ fontSize: 11, fill: '#6b7280' }}
                            axisLine={false}
                            tickLine={false}
                            tickFormatter={(v: number) => `₹${(v / 1000).toFixed(v >= 1000 ? 0 : 0)}k`}
                          />
                          <Tooltip
                            contentStyle={{
                              borderRadius: '8px',
                              border: '1px solid #e5e7eb',
                              boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
                              fontSize: '12px',
                            }}
                            formatter={(value: number) => [formatCurrency(value), 'Revenue']}
                            cursor={{ fill: 'rgba(16,185,129,0.08)' }}
                          />
                          <Bar
                            dataKey="revenue"
                            fill="#10b981"
                            radius={[4, 4, 0, 0]}
                            animationDuration={800}
                            animationEasing="ease-out"
                          />
                        </BarChart>
                      </ResponsiveContainer>
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* CSS-only Revenue Breakdown (Top Days) */}
              {cssRevenueBars.length > 0 && !invoiceLoading && (
                <Card className="mb-4">
                  <CardHeader className="pb-2 pt-4 px-5">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                        <TrendingUp className="h-4 w-4 text-green-600" />
                        Revenue Breakdown
                      </CardTitle>
                      <Badge variant="outline" className="text-xs font-normal">
                        Top {cssRevenueBars.length} days
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="px-5 pb-4">
                    <div className="space-y-2.5">
                      {cssRevenueBars.map((bar, idx) => (
                        <div key={bar.label} className="flex items-center gap-3 animate-grow-up" style={{ animationDelay: `${idx * 60}ms` }}>
                          <span className="text-xs text-muted-foreground w-16 shrink-0 text-right font-medium">
                            {bar.label}
                          </span>
                          <div className="flex-1 h-7 rounded-md bg-muted/50 overflow-hidden relative">
                            <div
                              className="h-full rounded-md bg-gradient-to-r from-green-500 to-emerald-400 animate-grow-up"
                              style={{ width: `${bar.widthPct}%`, animationDelay: `${idx * 60 + 100}ms` }}
                            />
                          </div>
                          <span className="text-xs font-mono font-semibold w-24 shrink-0 text-right text-foreground">
                            {formatCurrency(bar.value)}
                          </span>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              )}

              {/* Section Divider */}
              {invoiceData.length > 0 && !invoiceLoading && (
                <div className="flex items-center gap-3 mb-3 mt-2">
                  <Separator className="flex-1" />
                  <span className="text-xs text-muted-foreground font-medium">Transaction Details</span>
                  <Separator className="flex-1" />
                </div>
              )}

              {/* Transaction Table Header with CSV Export */}
              {invoiceData.length > 0 && !invoiceLoading && (
                <div className="flex items-center justify-end mb-2">
                  <Button
                    size="sm"
                    onClick={handleDownloadInvoiceCSV}
                    className="bg-green-600 hover:bg-green-700 text-white gap-1.5 hover-glow-green"
                  >
                    <Download className="h-4 w-4" />
                    Export CSV
                  </Button>
                </div>
              )}

              {invoiceLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : invoiceData.length === 0 ? (
                <div className="border-2 border-dashed border-muted-foreground/15 bg-gradient-to-b from-muted/20 to-transparent rounded-2xl p-6">
                  <div className="flex flex-col items-center justify-center py-10 text-muted-foreground">
                    <FileText className="h-12 w-12 mb-3 opacity-40 animate-float" />
                    <p className="text-sm">No invoice data found for the selected filters.</p>
                    <p className="text-[11px] text-muted-foreground/50 mt-2">
                      💡 Tip: Create invoices from the Bill Generator to see data here
                    </p>
                  </div>
                </div>
              ) : (
                <div className="rounded-lg border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="bg-muted/50">
                        <TableHead>Invoice No</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead className="hidden sm:table-cell">Customer</TableHead>
                        <TableHead>Payment Method</TableHead>
                        <TableHead className="text-right">Amount</TableHead>
                        <TableHead className="text-center">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {invoiceData.map((t, idx) => (
                        <TableRow key={idx} className="hover:bg-muted/30 transition-all duration-200">
                          <TableCell className="font-mono font-medium text-xs">
                            {t.invoiceNo}
                          </TableCell>
                          <TableCell className="text-sm">{t.date}</TableCell>
                          <TableCell className="hidden sm:table-cell">{t.customerName}</TableCell>
                          <TableCell>
                            <Badge variant="outline" className="text-xs">
                              {t.paymentMethod}
                            </Badge>
                          </TableCell>
                          <TableCell className="text-right font-mono">
                            {formatCurrency(t.amount)}
                          </TableCell>
                          <TableCell className="text-center">
                            <Badge variant={getStatusVariant(t.status)} className="text-xs">
                              {t.status}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>

            {/* ========== CASH REPORTS TAB ========== */}
            <TabsContent value="cash">
              <div className="flex items-center justify-between mb-2">
                <div
                  className="cursor-pointer text-sm text-green-600 hover:underline underline-offset-2 inline-block"
                  onClick={fetchCashReports}
                >
                  Refresh Cash Data
                </div>
                {cashReport && cashReport.transactions.length > 0 && (
                  <Button
                    size="sm"
                    onClick={handleDownloadCashCSV}
                    className="bg-green-600 hover:bg-green-700 text-white gap-1.5 hover-glow-green"
                  >
                    <Download className="h-4 w-4" />
                    Export CSV
                  </Button>
                )}
              </div>

              {cashLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : cashReport ? (
                <>
                  {/* Cash Summary */}
                  <div className="mb-4 grid gap-3 grid-cols-2 lg:grid-cols-4">
                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-900/30">
                          <Wallet className="h-5 w-5 text-slate-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Petty Cash</p>
                          <p className="text-lg font-bold">{formatCurrency(cashReport.pettyCash)}</p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                          <ArrowUpRight className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Total Income</p>
                          <p className="text-lg font-bold text-green-600">
                            {formatCurrency(cashReport.totalIncome)}
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/30">
                          <ArrowDownRight className="h-5 w-5 text-red-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Total Expense</p>
                          <p className="text-lg font-bold text-red-600">
                            {formatCurrency(cashReport.totalExpense)}
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                          <IndianRupee className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Balance</p>
                          <p className="text-lg font-bold">
                            {formatCurrency(cashReport.balance)}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Income vs Expense Donut Chart (recharts) */}
                  {cashPieData.length > 0 && (
                    <Card className="mb-4">
                      <CardHeader className="pb-2 pt-4 px-5">
                        <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                          <Wallet className="h-4 w-4 text-green-600" />
                          Income vs Expense Breakdown
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="px-5 pb-4">
                        <div className="flex flex-col sm:flex-row items-center gap-6">
                          <div className="h-56 w-56 shrink-0">
                            <ResponsiveContainer width="100%" height="100%">
                              <PieChart>
                                <Pie
                                  data={cashPieData}
                                  cx="50%"
                                  cy="50%"
                                  innerRadius={55}
                                  outerRadius={85}
                                  paddingAngle={3}
                                  dataKey="value"
                                  animationDuration={800}
                                  animationEasing="ease-out"
                                  stroke="none"
                                >
                                  {cashPieData.map((_entry, index) => (
                                    <Cell
                                      key={`cell-${index}`}
                                      fill={CASH_PIE_COLORS[index]}
                                    />
                                  ))}
                                </Pie>
                                <Tooltip
                                  contentStyle={{
                                    borderRadius: '8px',
                                    border: '1px solid #e5e7eb',
                                    boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
                                    fontSize: '12px',
                                  }}
                                  formatter={(value: number) => [formatCurrency(value)]}
                                />
                              </PieChart>
                            </ResponsiveContainer>
                          </div>
                          <div className="flex flex-col gap-3">
                            {cashPieData.map((entry, idx) => (
                              <div key={entry.name} className="flex items-center gap-3">
                                <span
                                  className="h-3 w-3 rounded-full shrink-0"
                                  style={{ backgroundColor: CASH_PIE_COLORS[idx] }}
                                />
                                <div>
                                  <p className="text-sm font-medium">{entry.name}</p>
                                  <p className="text-xs text-muted-foreground">
                                    {formatCurrency(entry.value)}
                                  </p>
                                </div>
                              </div>
                            ))}
                            {cashReport && (
                              <div className="mt-1 rounded-lg bg-muted/50 px-3 py-2">
                                <p className="text-xs text-muted-foreground">Net Balance</p>
                                <p
                                  className={`text-sm font-bold ${
                                    cashReport.balance >= 0 ? 'text-green-600' : 'text-red-600'
                                  }`}
                                >
                                  {formatCurrency(cashReport.balance)}
                                </p>
                              </div>
                            )}
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* CSS-only Cash Flow Overview */}
                  {cashFlowComparison && cashFlowComparison.total > 0 && (
                    <Card className="mb-4">
                      <CardHeader className="pb-2 pt-4 px-5">
                        <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                          <BarChart3 className="h-4 w-4 text-green-600" />
                          Cash Flow Overview
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="px-5 pb-4">
                        <div className="space-y-4">
                          {/* Income Bar */}
                          <div className="animate-grow-up">
                            <div className="flex items-center justify-between mb-1.5">
                              <div className="flex items-center gap-2">
                                <ArrowUpRight className="h-4 w-4 text-green-600" />
                                <span className="text-sm font-medium text-green-600">Income</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-muted-foreground">{cashFlowComparison.incomePct}%</span>
                                <span className="text-sm font-mono font-semibold">{formatCurrency(cashFlowComparison.income)}</span>
                              </div>
                            </div>
                            <div className="h-6 rounded-md bg-muted/50 overflow-hidden">
                              <div
                                className="h-full rounded-md bg-gradient-to-r from-green-500 to-emerald-400 transition-all duration-700 ease-out"
                                style={{ width: `${cashFlowComparison.incomePct}%` }}
                              />
                            </div>
                          </div>
                          {/* Expense Bar */}
                          <div className="animate-grow-up" style={{ animationDelay: '150ms' }}>
                            <div className="flex items-center justify-between mb-1.5">
                              <div className="flex items-center gap-2">
                                <ArrowDownRight className="h-4 w-4 text-red-600" />
                                <span className="text-sm font-medium text-red-600">Expense</span>
                              </div>
                              <div className="flex items-center gap-2">
                                <span className="text-xs text-muted-foreground">{cashFlowComparison.expensePct}%</span>
                                <span className="text-sm font-mono font-semibold">{formatCurrency(cashFlowComparison.expense)}</span>
                              </div>
                            </div>
                            <div className="h-6 rounded-md bg-muted/50 overflow-hidden">
                              <div
                                className="h-full rounded-md bg-gradient-to-r from-red-500 to-rose-400 transition-all duration-700 ease-out"
                                style={{ width: `${cashFlowComparison.expensePct}%` }}
                              />
                            </div>
                          </div>
                          {/* Net Balance */}
                          <div className="rounded-lg bg-muted/50 px-4 py-2.5 flex items-center justify-between">
                            <span className="text-xs text-muted-foreground">Net Cash Flow</span>
                            <span className={`text-sm font-bold ${cashReport!.balance >= 0 ? 'text-green-600' : 'text-red-600'}`}>
                              {cashReport!.balance >= 0 ? '+' : ''}{formatCurrency(cashReport!.balance)}
                            </span>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  {/* Section Divider */}
                  {cashReport.transactions.length > 0 && (
                    <div className="flex items-center gap-3 mb-3 mt-2">
                      <Separator className="flex-1" />
                      <span className="text-xs text-muted-foreground font-medium">Transaction Details</span>
                      <Separator className="flex-1" />
                    </div>
                  )}

                  {/* Cash Transaction History */}
                  {cashReport.transactions.length === 0 ? (
                    <div className="border-2 border-dashed border-muted-foreground/15 bg-gradient-to-b from-muted/20 to-transparent rounded-2xl p-6">
                      <div className="flex flex-col items-center justify-center py-6 text-muted-foreground">
                        <Wallet className="h-10 w-10 mb-2 opacity-40 animate-float" />
                        <p className="text-sm">No cash transactions found.</p>
                        <p className="text-[11px] text-muted-foreground/50 mt-2">
                          💡 Tip: Record income and expenses in Cash Manager to track cash flow
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-lg border overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-muted/50">
                            <TableHead>Date</TableHead>
                            <TableHead>Description</TableHead>
                            <TableHead className="text-center">Type</TableHead>
                            <TableHead className="text-right">Amount</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {cashReport.transactions.map((tx) => (
                            <TableRow key={tx.id} className="hover:bg-muted/30 transition-all duration-200">
                              <TableCell className="text-sm">{tx.date}</TableCell>
                              <TableCell>{tx.description}</TableCell>
                              <TableCell className="text-center">
                                <Badge
                                  variant={tx.type === 'income' ? 'default' : 'destructive'}
                                  className="text-xs"
                                >
                                  {tx.type === 'income' ? 'Income' : 'Expense'}
                                </Badge>
                              </TableCell>
                              <TableCell
                                className={`text-right font-mono ${tx.type === 'income' ? 'text-green-600' : 'text-red-600'}`}
                              >
                                {tx.type === 'income' ? '+' : '-'}
                                {formatCurrency(tx.amount)}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </>
              ) : (
                <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
                  <Wallet className="h-12 w-12 mb-3 opacity-40 animate-float" />
                  <p className="text-sm">Click &quot;Refresh Cash Data&quot; to load cash reports.</p>
                </div>
              )}
            </TabsContent>

            {/* ========== ATTENDANCE REPORTS TAB ========== */}
            <TabsContent value="attendance">
              <div className="flex items-center justify-between mb-2">
                <div
                  className="cursor-pointer text-sm text-green-600 hover:underline underline-offset-2 inline-block"
                  onClick={fetchAttendanceReports}
                >
                  Refresh Attendance Data
                </div>
                {attendanceReport && attendanceReport.staffList.length > 0 && (
                  <Button
                    size="sm"
                    onClick={handleDownloadAttendanceCSV}
                    className="bg-green-600 hover:bg-green-700 text-white gap-1.5 hover-glow-green"
                  >
                    <Download className="h-4 w-4" />
                    Export CSV
                  </Button>
                )}
              </div>

              {attendanceLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : attendanceReport ? (
                <>
                  {/* Attendance Summary */}
                  <div className="mb-4 grid gap-3 grid-cols-2 lg:grid-cols-4">
                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-900/30">
                          <Users className="h-5 w-5 text-slate-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Total Staff</p>
                          <p className="text-lg font-bold">{attendanceReport.totalStaff}</p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                          <UserCheck className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Present Today</p>
                          <p className="text-lg font-bold text-green-600">
                            {attendanceReport.presentToday}
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/30">
                          <UserX className="h-5 w-5 text-red-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Absent Today</p>
                          <p className="text-lg font-bold text-red-600">
                            {attendanceReport.absentToday}
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-amber-100 dark:bg-amber-900/30">
                          <Clock className="h-5 w-5 text-amber-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">On Leave</p>
                          <p className="text-lg font-bold text-amber-600">
                            {attendanceReport.onLeave}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Attendance Ratio Visual */}
                  <Card className="mb-4">
                    <CardHeader className="pb-2 pt-4 px-5">
                      <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                        <UserCheck className="h-4 w-4 text-green-600" />
                        Today&apos;s Attendance Overview
                      </CardTitle>
                    </CardHeader>
                    <CardContent className="px-5 pb-4">
                      <div className="flex flex-col sm:flex-row items-center gap-6">
                        {/* Radial Progress */}
                        <div className="h-44 w-44 shrink-0 relative">
                          <ResponsiveContainer width="100%" height="100%">
                            <PieChart>
                              <Pie
                                data={[
                                  { name: 'Present', value: attendanceRatio },
                                  { name: 'Absent/Leave', value: 100 - attendanceRatio },
                                ]}
                                cx="50%"
                                cy="50%"
                                innerRadius={52}
                                outerRadius={72}
                                startAngle={90}
                                endAngle={-270}
                                paddingAngle={0}
                                dataKey="value"
                                animationDuration={1000}
                                animationEasing="ease-out"
                                stroke="none"
                                cornerRadius={4}
                              >
                                <Cell fill="#10b981" />
                                <Cell fill="#f3f4f6" />
                              </Pie>
                            </PieChart>
                          </ResponsiveContainer>
                          {/* Center Label */}
                          <div className="absolute inset-0 flex flex-col items-center justify-center">
                            <span className="text-2xl font-bold text-green-600">{attendanceRatio}%</span>
                            <span className="text-[10px] text-muted-foreground">Present</span>
                          </div>
                        </div>
                        {/* Breakdown */}
                        <div className="flex flex-col gap-3 w-full">
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 shrink-0 rounded-full bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
                              <UserCheck className="h-4 w-4 text-green-600" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-xs font-medium text-muted-foreground">Present</span>
                                <span className="text-xs font-bold text-green-600">
                                  {attendanceReport.presentToday}/{attendanceReport.totalStaff}
                                </span>
                              </div>
                              <div className="h-2 rounded-full bg-muted overflow-hidden">
                                <div
                                  className="h-full rounded-full bg-green-500 transition-all duration-1000 ease-out"
                                  style={{ width: `${attendanceRatio}%` }}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 shrink-0 rounded-full bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
                              <UserX className="h-4 w-4 text-red-600" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-xs font-medium text-muted-foreground">Absent</span>
                                <span className="text-xs font-bold text-red-600">
                                  {attendanceReport.absentToday}/{attendanceReport.totalStaff}
                                </span>
                              </div>
                              <div className="h-2 rounded-full bg-muted overflow-hidden">
                                <div
                                  className="h-full rounded-full bg-red-400 transition-all duration-1000 ease-out"
                                  style={{
                                    width: `${attendanceReport.totalStaff > 0 ? (attendanceReport.absentToday / attendanceReport.totalStaff) * 100 : 0}%`,
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                          <div className="flex items-center gap-3">
                            <div className="h-8 w-8 shrink-0 rounded-full bg-amber-100 dark:bg-amber-900/30 flex items-center justify-center">
                              <Clock className="h-4 w-4 text-amber-600" />
                            </div>
                            <div className="flex-1">
                              <div className="flex items-center justify-between mb-1">
                                <span className="text-xs font-medium text-muted-foreground">On Leave</span>
                                <span className="text-xs font-bold text-amber-600">
                                  {attendanceReport.onLeave}/{attendanceReport.totalStaff}
                                </span>
                              </div>
                              <div className="h-2 rounded-full bg-muted overflow-hidden">
                                <div
                                  className="h-full rounded-full bg-amber-400 transition-all duration-1000 ease-out"
                                  style={{
                                    width: `${attendanceReport.totalStaff > 0 ? (attendanceReport.onLeave / attendanceReport.totalStaff) * 100 : 0}%`,
                                  }}
                                />
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>

                  {/* Section Divider */}
                  {attendanceReport.staffList.length > 0 && (
                    <div className="flex items-center gap-3 mb-3 mt-2">
                      <Separator className="flex-1" />
                      <span className="text-xs text-muted-foreground font-medium">Staff Details</span>
                      <Separator className="flex-1" />
                    </div>
                  )}

                  {/* Staff Attendance Table */}
                  {attendanceReport.staffList.length === 0 ? (
                    <div className="border-2 border-dashed border-muted-foreground/15 bg-gradient-to-b from-muted/20 to-transparent rounded-2xl p-6">
                      <div className="flex flex-col items-center justify-center py-6 text-muted-foreground">
                        <Users className="h-10 w-10 mb-2 opacity-40 animate-float" />
                        <p className="text-sm">No staff attendance data found.</p>
                        <p className="text-[11px] text-muted-foreground/50 mt-2">
                          💡 Tip: Mark staff attendance from the Staff &amp; Attendance page
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-lg border overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-muted/50">
                            <TableHead>Name</TableHead>
                            <TableHead className="hidden sm:table-cell">Designation</TableHead>
                            <TableHead className="text-center">Status</TableHead>
                            <TableHead className="hidden sm:table-cell text-center">Check In</TableHead>
                            <TableHead className="hidden sm:table-cell text-center">Check Out</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {attendanceReport.staffList.map((s) => (
                            <TableRow key={s.id} className="hover:bg-muted/30 transition-all duration-200">
                              <TableCell className="font-medium">{s.name}</TableCell>
                              <TableCell className="hidden sm:table-cell text-muted-foreground">
                                {s.designation}
                              </TableCell>
                              <TableCell className="text-center">
                                {s.status === 'present' && (
                                  <Badge className="bg-green-600 text-white text-xs">Present</Badge>
                                )}
                                {s.status === 'absent' && (
                                  <Badge variant="destructive" className="text-xs">Absent</Badge>
                                )}
                                {s.status === 'on-leave' && (
                                  <Badge className="bg-amber-500 text-white text-xs">On Leave</Badge>
                                )}
                              </TableCell>
                              <TableCell className="hidden sm:table-cell text-center text-sm">
                                {s.checkIn || '—'}
                              </TableCell>
                              <TableCell className="hidden sm:table-cell text-center text-sm">
                                {s.checkOut || '—'}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </>
              ) : (
                <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
                  <Users className="h-12 w-12 mb-3 opacity-40 animate-float" />
                  <p className="text-sm">Click &quot;Refresh Attendance Data&quot; to load attendance reports.</p>
                </div>
              )}
            </TabsContent>

            {/* ========== KHATA REPORTS TAB ========== */}
            <TabsContent value="khata">
              <div className="flex items-center justify-between mb-2">
                <div
                  className="cursor-pointer text-sm text-green-600 hover:underline underline-offset-2 inline-block"
                  onClick={fetchKhataReports}
                >
                  Refresh Khata Data
                </div>
                {khataReport && khataReport.profiles.length > 0 && (
                  <Button
                    size="sm"
                    onClick={handleDownloadKhataCSV}
                    className="bg-green-600 hover:bg-green-700 text-white gap-1.5 hover-glow-green"
                  >
                    <Download className="h-4 w-4" />
                    Export CSV
                  </Button>
                )}
              </div>

              {khataLoading ? (
                <div className="space-y-2">
                  <Skeleton className="h-24 w-full" />
                  <Skeleton className="h-10 w-full" />
                  <Skeleton className="h-10 w-full" />
                </div>
              ) : khataReport ? (
                <>
                  {/* Khata Summary */}
                  <div className="mb-4 grid gap-3 grid-cols-1 sm:grid-cols-3">
                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-green-100 dark:bg-green-900/30">
                          <ArrowUpRight className="h-5 w-5 text-green-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Total Receivable</p>
                          <p className="text-lg font-bold text-green-600">
                            {formatCurrency(khataReport.totalReceivable)}
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-100 dark:bg-red-900/30">
                          <ArrowDownRight className="h-5 w-5 text-red-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Total Payable</p>
                          <p className="text-lg font-bold text-red-600">
                            {formatCurrency(khataReport.totalPayable)}
                          </p>
                        </div>
                      </CardContent>
                    </Card>

                    <Card className="py-4 card-hover-glow">
                      <CardContent className="flex items-center gap-3">
                        <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-slate-100 dark:bg-slate-900/30">
                          <BookOpen className="h-5 w-5 text-slate-600" />
                        </div>
                        <div>
                          <p className="text-xs text-muted-foreground">Net Position</p>
                          <p
                            className={`text-lg font-bold ${khataReport.netPosition >= 0 ? 'text-green-600' : 'text-red-600'}`}
                          >
                            {khataReport.netPosition >= 0 ? '+' : ''}
                            {formatCurrency(khataReport.netPosition)}
                          </p>
                        </div>
                      </CardContent>
                    </Card>
                  </div>

                  {/* Top Receivable & Payable Charts */}
                  {(khataTopProfiles.receivable.length > 0 || khataTopProfiles.payable.length > 0) && (
                    <div className="mb-4 grid gap-4 grid-cols-1 lg:grid-cols-2">
                      {/* Top Receivable */}
                      {khataTopProfiles.receivable.length > 0 && (
                        <Card>
                          <CardHeader className="pb-2 pt-4 px-5">
                            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                              <ArrowUpRight className="h-4 w-4 text-green-600" />
                              Top Receivables
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="px-5 pb-4">
                            <div className="h-64">
                              <ResponsiveContainer width="100%" height="100%">
                                <BarChart
                                  data={khataTopProfiles.receivable}
                                  layout="vertical"
                                  margin={{ top: 4, right: 24, left: 8, bottom: 4 }}
                                >
                                  <XAxis
                                    type="number"
                                    tick={{ fontSize: 11, fill: '#6b7280' }}
                                    axisLine={false}
                                    tickLine={false}
                                    tickFormatter={(v: number) => `₹${(v / 1000).toFixed(v >= 1000 ? 1 : 0)}k`}
                                  />
                                  <YAxis
                                    type="category"
                                    dataKey="name"
                                    tick={{ fontSize: 11, fill: '#374151' }}
                                    axisLine={false}
                                    tickLine={false}
                                    width={80}
                                  />
                                  <Tooltip
                                    contentStyle={{
                                      borderRadius: '8px',
                                      border: '1px solid #e5e7eb',
                                      boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
                                      fontSize: '12px',
                                    }}
                                    formatter={(value: number) => [formatCurrency(value), 'Amount']}
                                    cursor={{ fill: 'rgba(16,185,129,0.08)' }}
                                  />
                                  <Bar
                                    dataKey="balance"
                                    fill="#10b981"
                                    radius={[0, 4, 4, 0]}
                                    animationDuration={800}
                                    animationEasing="ease-out"
                                  />
                                </BarChart>
                              </ResponsiveContainer>
                            </div>
                          </CardContent>
                        </Card>
                      )}

                      {/* Top Payable */}
                      {khataTopProfiles.payable.length > 0 && (
                        <Card>
                          <CardHeader className="pb-2 pt-4 px-5">
                            <CardTitle className="text-sm font-medium text-muted-foreground flex items-center gap-1.5">
                              <ArrowDownRight className="h-4 w-4 text-red-600" />
                              Top Payables
                            </CardTitle>
                          </CardHeader>
                          <CardContent className="px-5 pb-4">
                            <div className="h-64">
                              <ResponsiveContainer width="100%" height="100%">
                                <BarChart
                                  data={khataTopProfiles.payable}
                                  layout="vertical"
                                  margin={{ top: 4, right: 24, left: 8, bottom: 4 }}
                                >
                                  <XAxis
                                    type="number"
                                    tick={{ fontSize: 11, fill: '#6b7280' }}
                                    axisLine={false}
                                    tickLine={false}
                                    tickFormatter={(v: number) => `₹${(v / 1000).toFixed(v >= 1000 ? 1 : 0)}k`}
                                  />
                                  <YAxis
                                    type="category"
                                    dataKey="name"
                                    tick={{ fontSize: 11, fill: '#374151' }}
                                    axisLine={false}
                                    tickLine={false}
                                    width={80}
                                  />
                                  <Tooltip
                                    contentStyle={{
                                      borderRadius: '8px',
                                      border: '1px solid #e5e7eb',
                                      boxShadow: '0 4px 6px -1px rgba(0,0,0,0.1)',
                                      fontSize: '12px',
                                    }}
                                    formatter={(value: number) => [formatCurrency(value), 'Amount']}
                                    cursor={{ fill: 'rgba(239,68,68,0.08)' }}
                                  />
                                  <Bar
                                    dataKey="balance"
                                    fill="#ef4444"
                                    radius={[0, 4, 4, 0]}
                                    animationDuration={800}
                                    animationEasing="ease-out"
                                  />
                                </BarChart>
                              </ResponsiveContainer>
                            </div>
                          </CardContent>
                        </Card>
                      )}
                    </div>
                  )}

                  {/* Section Divider */}
                  {khataReport.profiles.length > 0 && (
                    <div className="flex items-center gap-3 mb-3 mt-2">
                      <Separator className="flex-1" />
                      <span className="text-xs text-muted-foreground font-medium">Profile Details</span>
                      <Separator className="flex-1" />
                    </div>
                  )}

                  {/* Profiles Table */}
                  {khataReport.profiles.length === 0 ? (
                    <div className="border-2 border-dashed border-muted-foreground/15 bg-gradient-to-b from-muted/20 to-transparent rounded-2xl p-6">
                      <div className="flex flex-col items-center justify-center py-6 text-muted-foreground">
                        <BookOpen className="h-10 w-10 mb-2 opacity-40 animate-float" />
                        <p className="text-sm">No khata profiles found.</p>
                        <p className="text-[11px] text-muted-foreground/50 mt-2">
                          💡 Tip: Create customer/supplier profiles in Khata Book to manage credit
                        </p>
                      </div>
                    </div>
                  ) : (
                    <div className="rounded-lg border overflow-hidden">
                      <Table>
                        <TableHeader>
                          <TableRow className="bg-muted/50">
                            <TableHead>Name</TableHead>
                            <TableHead className="text-center">Type</TableHead>
                            <TableHead className="text-right">Balance</TableHead>
                          </TableRow>
                        </TableHeader>
                        <TableBody>
                          {khataReport.profiles.map((p) => (
                            <TableRow key={p.id} className="hover:bg-muted/30 transition-all duration-200">
                              <TableCell className="font-medium">{p.name}</TableCell>
                              <TableCell className="text-center">
                                <Badge
                                  variant={p.type === 'receivable' ? 'default' : 'destructive'}
                                  className="text-xs"
                                >
                                  {p.type === 'receivable' ? 'Receivable' : 'Payable'}
                                </Badge>
                              </TableCell>
                              <TableCell
                                className={`text-right font-mono ${p.type === 'receivable' ? 'text-green-600' : 'text-red-600'}`}
                              >
                                {formatCurrency(p.balance)}
                              </TableCell>
                            </TableRow>
                          ))}
                        </TableBody>
                      </Table>
                    </div>
                  )}
                </>
              ) : (
                <div className="flex flex-col items-center justify-center py-16 text-muted-foreground">
                  <BookOpen className="h-12 w-12 mb-3 opacity-40 animate-float" />
                  <p className="text-sm">Click &quot;Refresh Khata Data&quot; to load khata reports.</p>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
}
