'use client';

import React, { useState, useEffect, useCallback, useRef } from 'react';
import {
  Settings, Store, Printer, Database, Save, RotateCcw, Download, Upload,
  Loader2, AlertTriangle, Check, ChevronDown, ChevronUp, FileText, Receipt, Scissors, X,
  ImageIcon, Trash2, Users, Shield, Lock, Eye, EyeOff,
} from 'lucide-react';
import { Card, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Separator } from '@/components/ui/separator';
import { Switch } from '@/components/ui/switch';
import { Slider } from '@/components/ui/slider';
import { Badge } from '@/components/ui/badge';
import { RadioGroup, RadioGroupItem } from '@/components/ui/radio-group';
import {
  AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent,
  AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger,
} from '@/components/ui/alert-dialog';
import { Skeleton } from '@/components/ui/skeleton';
import { toast } from 'sonner';
import { buildRichThermalHtml, type ThermalReceiptData } from '@/lib/thermal-settings';
import { useAuth } from '@/components/auth-provider';
import UserManagementSection from '@/components/sections/user-management-section';
// ── Types & Defaults ─────────────────────────────────────────────────────────

interface ThermalPrinterSettings {
  paperWidth: '58mm' | '80mm';
  fontSize: number;            // px: 8-18
  lineHeight: number;          // 1.0-2.0
  textWeight: 'Bold' | 'Normal' | 'Light';
  printDpi: number;            // 203 | 300
  printQuality: 'Dark' | 'Light';
  dithering: 'None' | 'Floyd Steinberg' | 'Black & White';
  showLogo: boolean;
  logo: string;                // base64 data URL
}

interface SettingsSectionProps { scrollToId?: string; }

const DEFAULT_THERMAL: ThermalPrinterSettings = {
  paperWidth: '80mm', fontSize: 11, lineHeight: 1.3,
  printDpi: 203,
  textWeight: 'Normal',
  printQuality: 'Dark',
  dithering: 'None',
  showLogo: false,
  logo: '',
};

const WEIGHT_MAP: Record<string, number> = { Bold: 700, Normal: 400, Light: 300 };
const QUALITY_OPACITY: Record<string, number> = { Dark: 1, Light: 0.6 };
const INPUT_CLS = 'focus-visible:ring-green-500/20 focus-visible:border-green-500/50';

// Map UI ThermalPrinterSettings → ThermalConfig for buildRichThermalHtml
function uiToConfig(t: ThermalPrinterSettings) {
  return {
    paperWidth: t.paperWidth,
    fontSize: `${t.fontSize}px`,
    textWeight: WEIGHT_MAP[t.textWeight] ?? 400,
    lineHeight: t.lineHeight,
    printDpi: t.printDpi,
    printQuality: QUALITY_OPACITY[t.printQuality] ?? 1,
    dithering: t.dithering,
    alignment: 'center' as const,
    showLogo: t.showLogo,
    logo: t.logo,
    paperPxWidth: t.paperWidth === '80mm' ? 302 : 224,
    autoCutLines: 2,
  };
}

// ── Reusable: Collapsible Section ────────────────────────────────────────────

function Section({
  id, icon, title, desc, children, open: defaultOpen = true, badge,
}: {
  id: string; icon: React.ReactNode; title: string; desc: string;
  children: React.ReactNode; open?: boolean; badge?: React.ReactNode;
}) {
  const [o, setO] = useState(defaultOpen);
  return (
    <Card className="overflow-hidden border-0 shadow-sm transition-all duration-200 hover:shadow-md">
      <button className="w-full text-left" onClick={() => setO(!o)}>
        <CardHeader className="cursor-pointer hover:bg-muted/30 transition-colors py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="flex size-9 items-center justify-center rounded-lg bg-green-100 text-green-600 shrink-0">{icon}</div>
              <div className="min-w-0">
                <CardTitle className="text-base flex items-center gap-2">{title}{badge}</CardTitle>
                <CardDescription className="mt-0.5 truncate">{desc}</CardDescription>
              </div>
            </div>
            <div className="shrink-0 text-muted-foreground">{o ? <ChevronUp className="size-5" /> : <ChevronDown className="size-5" />}</div>
          </div>
        </CardHeader>
      </button>
      {o && <div className="px-6 pb-6">{children}</div>}
    </Card>
  );
}

function Divider({ icon, label }: { icon: React.ReactNode; label: string }) {
  return (
    <div className="flex items-center gap-3 py-2">
      <Separator className="flex-1" />
      <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider flex items-center gap-1.5">{icon}{label}</span>
      <Separator className="flex-1" />
    </div>
  );
}

function SaveBtn({ section, label, onClick, saving, saved }: {
  section: string; label: string; onClick: () => void; saving: string | null; saved: string | null;
}) {
  const s = saving === section, d = saved === section;
  return (
    <div className="flex justify-end">
      <Button onClick={onClick} disabled={s} className={`gap-1.5 transition-all duration-300 ${d ? 'bg-green-500 hover:bg-green-600' : 'bg-green-600 hover:bg-green-700'} text-white`}>
        {s ? <Loader2 className="h-4 w-4 animate-spin" /> : d ? <><Check className="h-4 w-4" />Saved!</> : <><Save className="h-4 w-4" />{label}</>}
      </Button>
    </div>
  );
}

function SavedBadge({ section, saved }: { section: string; saved: string | null }) {
  if (saved !== section) return null;
  return <Badge className="bg-green-100 text-green-700 border-green-200 text-[10px] gap-0.5"><Check className="size-3" />Saved</Badge>;
}

// ── Receipt Preview (iframe-based WYSIWYG) ──────────────────────────────────

function ReceiptPreview({ shopName, shopAddress, shopPhone, gstNumber, showGst, t }: { shopName: string; shopAddress: string; shopPhone: string; gstNumber: string; showGst: boolean; t: ThermalPrinterSettings }) {
  const config = uiToConfig(t);
  const sampleData: ThermalReceiptData = {
    shopName: shopName || 'My Shop',
    shopAddress: shopAddress || '123, Main Road',
    shopPhone: shopPhone || '+91 98765 43210',
    shopGst: gstNumber,
    shopGstState: '',
    showGst: showGst,
    invoiceNumber: 'FP-001',
    date: new Date().toLocaleDateString('en-IN'),
    orderType: 'Dine-In',
    customerName: 'Walk-in Customer',
    customerPhone: '',
    customerAddress: '',
    items: [
      { name: 'Item 1', qty: 1, rate: 150, total: 150 },
      { name: 'Item 2', qty: 2, rate: 100, total: 200 },
      { name: 'Item 3', qty: 1, rate: 75, total: 75 },
    ],
    subtotal: 425,
    cgst: 38.25,
    sgst: 38.25,
    gstRate: 18,
    deliveryCharge: 0,
    discountAmount: 0,
    grandTotal: 501.5,
    paidAmount: 501.5,
    balanceAmount: 0,
    paymentMethod: 'Cash',
    billStatus: 'Paid',
  };
  const html = buildRichThermalHtml(sampleData, config, 'Preview');
  const iframeMaxW = t.paperWidth === '58mm' ? 224 : 302;

  return (
    <div className="bg-white border-2 border-dashed border-gray-300 rounded-lg p-2 mx-auto transition-all duration-200" style={{ maxWidth: `${iframeMaxW + 24}px` }}>
      <iframe
        srcDoc={html}
        title="Receipt Preview"
        style={{
          width: `${iframeMaxW}px`,
          height: 'auto',
          minHeight: '380px',
          border: 'none',
          overflow: 'hidden',
          display: 'block',
        }}
        sandbox="allow-same-origin"
      />
    </div>
  );
}

// ── Radio Option Helper ──────────────────────────────────────────────────────

function RadioOpt({ id, value, label, group }: { id: string; value: string; label: string; group: string }) {
  return (
    <div className="flex items-center gap-2">
      <RadioGroupItem value={value} id={id} />
      <Label htmlFor={id} className="cursor-pointer">{label}</Label>
    </div>
  );
}

// ── Slider Field Helper ──────────────────────────────────────────────────────

function SliderField({ label, value, min, max, unit, onChange, icon }: {
  label: string; value: number; min: number; max: number; unit: string;
  onChange: (v: number) => void; icon?: React.ReactNode;
}) {
  return (
    <div className="grid gap-2">
      <div className="flex items-center justify-between">
        <Label className={icon ? 'flex items-center gap-1.5' : ''}>{icon}{label}</Label>
        <Badge variant="outline" className="font-mono">{value}{unit}</Badge>
      </div>
      <Slider value={[value]} onValueChange={(v) => onChange(v[0])} min={min} max={max} step={1} />
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>{min}{unit}</span><span>{max}{unit}</span>
      </div>
    </div>
  );
}

// ── Main Component ───────────────────────────────────────────────────────────

function ChangePasswordSection() {
  const { currentUser } = useAuth();
  const [currentPassword, setCurrentPassword] = useState('');
  const [newPassword, setNewPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [showCurrent, setShowCurrent] = useState(false);
  const [showNew, setShowNew] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleChangePassword = async () => {
    if (!currentPassword || !newPassword || !confirmPassword) {
      toast.error('All fields are required');
      return;
    }
    if (newPassword.length < 4) {
      toast.error('New password must be at least 4 characters');
      return;
    }
    if (newPassword !== confirmPassword) {
      toast.error('New passwords do not match');
      return;
    }
    setLoading(true);
    try {
      const res = await fetch(`/api/users/${currentUser?.userId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          currentPassword,
          password: newPassword,
        }),
      });
      if (res.ok) {
        toast.success('Password changed successfully');
        setCurrentPassword('');
        setNewPassword('');
        setConfirmPassword('');
      } else {
        const data = await res.json().catch(() => null);
        toast.error(data?.error || 'Failed to change password');
      }
    } catch {
      toast.error('Network error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Card className="overflow-hidden border-0 shadow-sm">
      <CardHeader className="pb-2">
        <div className="flex items-center gap-3">
          <div className="flex size-9 items-center justify-center rounded-lg bg-amber-100 text-amber-600 shrink-0">
            <Lock className="size-4" />
          </div>
          <div className="min-w-0">
            <CardTitle className="text-base">Change Password</CardTitle>
            <CardDescription className="mt-0.5">Update your account password</CardDescription>
          </div>
        </div>
      </CardHeader>
      <div className="px-6 pb-6 space-y-4">
        <div className="grid gap-2 border-l-2 border-l-amber-400 pl-3">
          <Label className="text-sm font-medium">Current Password</Label>
          <div className="relative">
            <Input
              type={showCurrent ? 'text' : 'password'}
              placeholder="Enter current password"
              value={currentPassword}
              onChange={(e) => setCurrentPassword(e.target.value)}
              className="pr-10"
            />
            <button type="button" onClick={() => setShowCurrent(!showCurrent)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              {showCurrent ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </div>
        <div className="grid gap-2 border-l-2 border-l-amber-400 pl-3">
          <Label className="text-sm font-medium">New Password</Label>
          <div className="relative">
            <Input
              type={showNew ? 'text' : 'password'}
              placeholder="Enter new password (min 4 chars)"
              value={newPassword}
              onChange={(e) => setNewPassword(e.target.value)}
              className="pr-10"
            />
            <button type="button" onClick={() => setShowNew(!showNew)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              {showNew ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </div>
        <div className="grid gap-2 border-l-2 border-l-amber-400 pl-3">
          <Label className="text-sm font-medium">Confirm New Password</Label>
          <div className="relative">
            <Input
              type={showConfirm ? 'text' : 'password'}
              placeholder="Confirm new password"
              value={confirmPassword}
              onChange={(e) => setConfirmPassword(e.target.value)}
              className="pr-10"
            />
            <button type="button" onClick={() => setShowConfirm(!showConfirm)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground">
              {showConfirm ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
        </div>
        <div className="flex justify-end">
          <Button onClick={handleChangePassword} disabled={loading} className="gap-1.5 bg-amber-600 hover:bg-amber-700 text-white">
            {loading ? <Loader2 className="size-4 animate-spin" /> : <><Lock className="size-4" />Update Password</>}
          </Button>
        </div>
      </div>
    </Card>
  );
}

// ── Main Component ───────────────────────────────────────────────────────────

export default function SettingsSection({ scrollToId }: SettingsSectionProps) {
  const { currentUser, isAdmin, hasPermission, refreshSession } = useAuth();
  useEffect(() => {
    if (!scrollToId) return;
    const t = setTimeout(() => {
      const el = document.getElementById(scrollToId);
      if (el) el.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 300);
    return () => clearTimeout(t);
  }, [scrollToId]);

  // Refresh session permissions from DB when Settings page loads
  // This ensures that if Admin just granted this user permission changes, they take effect immediately
  useEffect(() => {
    refreshSession();
  }, [refreshSession]);

  const [loading, setLoading] = useState(true);
  const [savingSection, setSavingSection] = useState<string | null>(null);
  const [savedSection, setSavedSection] = useState<string | null>(null);
  const saveTimer = useRef<NodeJS.Timeout | null>(null);

  // Cleanup saveTimer on unmount to prevent memory leak
  useEffect(() => {
    return () => {
      if (saveTimer.current) clearTimeout(saveTimer.current);
    };
  }, []);

  // Business
  const [shopName, setShopName] = useState('');
  const [address, setAddress] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [signatory, setSignatory] = useState('');
  const [gstNumber, setGstNumber] = useState('');

  // Billing
  const [gstEnabled, setGstEnabled] = useState(false);
  const [gstFullMode, setGstFullMode] = useState(false);
  const [gstSimpleMode, setGstSimpleMode] = useState(false);
  const [gstRate, setGstRate] = useState(18);
  const [gstState, setGstState] = useState('');
  const [deliveryCharge, setDeliveryCharge] = useState(0);

  // Thermal (localStorage)
  const [thermal, setThermal] = useState<ThermalPrinterSettings>(DEFAULT_THERMAL);
  const [thermalSaved, setThermalSaved] = useState(false);
  const logoInputRef = useRef<HTMLInputElement>(null);

  // Data management
  const [resetOpen, setResetOpen] = useState(false);
  const [resetting, setResetting] = useState(false);
  const importRef = useRef<HTMLInputElement>(null);

  // Load DB settings
  const fetchSettings = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetch('/api/settings');
      if (res.ok) {
        const d = await res.json();
        const name = d.shopName || '';
        const addr = d.shopAddress || '';
        const eml = d.shopEmail || '';
        const ph = d.shopPhone || '';
        const sig = d.authorizedSignatory || '';
        const gst = d.gstNumber || '';
        setShopName(name);
        setAddress(addr);
        setEmail(eml);
        setPhone(ph);
        setSignatory(sig);
        setGstNumber(gst);
        setGstEnabled(d.enableGst ?? false);
        setGstFullMode(d.gstFullMode ?? false);
        setGstSimpleMode(d.gstSimpleMode ?? false);
        setGstRate(d.gstRate ?? 18);
        setGstState(d.gstState || '');
        setDeliveryCharge(d.deliveryCharge ?? 0);
        // Pre-populate demo data if business info is empty
        // Note: gstNumber is NOT pre-filled — user must manually enter it in GST settings
        if (!addr && !eml && !ph && !sig) {
          const demoData = {
            shopName: name || 'Eservices',
            shopAddress: '123, Main Market Road, City Center',
            shopEmail: 'info@eservices.in',
            shopPhone: '+91 98765 43210',
            authorizedSignatory: 'Rajesh Kumar',
          };
          fetch('/api/settings', {
            method: 'PUT',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(demoData),
          }).then((r) => { if (r.ok) { setShopName(demoData.shopName); setAddress(demoData.shopAddress); setEmail(demoData.shopEmail); setPhone(demoData.shopPhone); setSignatory(demoData.authorizedSignatory); toast.success('Demo business information loaded'); } }).catch(() => {});
          // Do NOT set gstNumber from demo data — user must enable GST mode first
        }
        // Store full settings for thermal merge
        setDbSettings(d);
      }
    } catch { toast.error('Failed to load settings'); }
    finally { setLoading(false); }
  }, []);

  // Track DB settings for thermal merging
  const [dbSettings, setDbSettings] = useState<Record<string, unknown> | null>(null);

  // Load thermal from localStorage (initial fast load)
  useEffect(() => {
    try {
      const raw = localStorage.getItem('fp_thermal_settings');
      if (raw) setThermal({ ...DEFAULT_THERMAL, ...JSON.parse(raw) });
    } catch { /* use defaults */ }
  }, []);

  // Merge thermal settings from DB — only if localStorage has no saved values yet
  useEffect(() => {
    if (!dbSettings) return;
    // If localStorage already has thermal settings, those take priority (user's latest edits)
    const hasLocal = localStorage.getItem('fp_thermal_settings');
    if (hasLocal) return;
    // No localStorage — use DB values as defaults
    setThermal(prev => ({
      ...prev,
      paperWidth: (dbSettings.thermalPaperWidth || prev.paperWidth) as '58mm' | '80mm',
      fontSize: (typeof dbSettings.thermalFontSize === 'number' ? dbSettings.thermalFontSize : prev.fontSize) as number,
      lineHeight: (typeof dbSettings.thermalLineHeight === 'number' ? dbSettings.thermalLineHeight : prev.lineHeight) as number,
      textWeight: (dbSettings.thermalTextWeight || prev.textWeight) as ThermalPrinterSettings['textWeight'],
      printDpi: (dbSettings.thermalDpi ?? prev.printDpi) as number,
      printQuality: (dbSettings.thermalPrintQuality || prev.printQuality) as ThermalPrinterSettings['printQuality'],
      dithering: (dbSettings.thermalDithering || prev.dithering) as ThermalPrinterSettings['dithering'],
      showLogo: (dbSettings.thermalShowLogo ?? prev.showLogo) as boolean,
      logo: (dbSettings.thermalLogo || prev.logo) as string,
    }));
  }, [dbSettings]);

  useEffect(() => { fetchSettings(); }, [fetchSettings]);

  // API save helper
  const saveApi = async (section: string, data: Record<string, unknown>) => {
    setSavingSection(section);
    setSavedSection(null);
    if (saveTimer.current) clearTimeout(saveTimer.current);
    try {
      const res = await fetch('/api/settings', {
        method: 'PUT', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ section, ...data }),
      });
      if (res.ok) {
        toast.success(`${section} settings saved`);
        setSavedSection(section);
        saveTimer.current = setTimeout(() => setSavedSection(null), 3000);
      } else toast.error(`Failed to save ${section} settings`);
    } catch { toast.error(`Failed to save ${section} settings`); }
    finally { setSavingSection(null); }
  };

  const patch = (p: Partial<ThermalPrinterSettings>) => setThermal((prev) => {
    const updated = { ...prev, ...p };
    // Auto-save to localStorage so changes persist across page reloads
    try { localStorage.setItem('fp_thermal_settings', JSON.stringify(updated)); } catch { /* ignore */ }
    return updated;
  });

  if (loading) {
    return (
      <div className="space-y-4">
        {[1, 2, 3].map((i) => (
          <Card key={i}><CardHeader><Skeleton className="h-6 w-48" /><Skeleton className="h-4 w-72" /></CardHeader>
            <div className="px-6 pb-6 space-y-4"><Skeleton className="h-9 w-full" /><Skeleton className="h-9 w-full" /></div>
          </Card>
        ))}
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-green-600 via-emerald-600 to-teal-600 p-5 md:p-6 text-white shadow-lg shadow-green-600/20">
        <div className="pointer-events-none absolute -right-8 -top-8 size-36 rounded-full bg-white/10" />
        <div className="pointer-events-none absolute -bottom-6 -left-6 size-28 rounded-full bg-white/5" />
        <div className="relative z-10">
          <h2 className="text-xl md:text-2xl font-bold tracking-tight flex items-center gap-2"><Settings className="size-6" />Settings</h2>
          <p className="text-green-100 text-sm mt-1">Configure your business preferences and printer settings</p>
        </div>
      </div>

      {/* ═══ Business Information ═══ */}
      <Section id="business" icon={<Store className="h-5 w-5" />} title="Business Information" desc="Your shop details and contact information" badge={<SavedBadge section="business" saved={savedSection} />}>
        <div className="space-y-4">
          <div className="grid gap-4 sm:grid-cols-2 border-l-2 border-l-green-400 pl-3">
            <div className="grid gap-2"><Label htmlFor="shop-name">Shop Name</Label>
              <Input id="shop-name" placeholder="Enter shop name" value={shopName} onChange={(e) => setShopName(e.target.value)} className={INPUT_CLS} /></div>
            <div className="grid gap-2"><Label htmlFor="auth-sig">Authorized Signatory</Label>
              <Input id="auth-sig" placeholder="Full name" value={signatory} onChange={(e) => setSignatory(e.target.value)} className={INPUT_CLS} /></div>
          </div>
          <div className="grid gap-4 sm:grid-cols-2 border-l-2 border-l-green-400 pl-3">
            <div className="grid gap-2"><Label htmlFor="email">Email</Label>
              <Input id="email" type="email" placeholder="shop@example.com" value={email} onChange={(e) => setEmail(e.target.value)} className={INPUT_CLS} /></div>
            <div className="grid gap-2"><Label htmlFor="phone">Phone Number</Label>
              <Input id="phone" type="tel" placeholder="+91 98765 43210" value={phone} onChange={(e) => setPhone(e.target.value)} className={INPUT_CLS} /></div>
          </div>
          <div className="grid gap-2 border-l-2 border-l-green-400 pl-3">
            <Label htmlFor="address">Address</Label>
            <Textarea id="address" placeholder="Full shop address" value={address} onChange={(e) => setAddress(e.target.value)} rows={3} className={INPUT_CLS} />
          </div>
          <SaveBtn section="business" label="Save Business Info" onClick={() => saveApi('business', { shopName, shopAddress: address, shopEmail: email, shopPhone: phone, authorizedSignatory: signatory })} saving={savingSection} saved={savedSection} />
        </div>
      </Section>

      {/* ═══ Billing Configuration ═══ */}
      <Divider icon={<FileText className="size-3" />} label="Billing" />

      {/* GST */}
      <Section id="gst" icon={<FileText className="h-5 w-5" />} title="GST & Tax Configuration" desc="Configure GST modes, rates, and tax invoice settings" badge={<SavedBadge section="gst" saved={savedSection} />}>
        <div className="space-y-4">
          {/* ── Mode Selector ── */}
          <div className="grid gap-3 sm:grid-cols-2">
            {/* Full Mode Card */}
            <div
              role="button"
              tabIndex={0}
              onClick={() => { setGstFullMode(!gstFullMode); if (!gstFullMode) setGstSimpleMode(false); if (!gstFullMode) setGstEnabled(true); }}
              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setGstFullMode(!gstFullMode); if (!gstFullMode) setGstSimpleMode(false); if (!gstFullMode) setGstEnabled(true); } }}
              className={`relative text-left rounded-xl border-2 p-4 transition-all duration-200 cursor-pointer ${
                gstFullMode
                  ? 'border-green-400 bg-green-50/60 dark:border-green-600 dark:bg-green-950/30 shadow-md shadow-green-600/10'
                  : 'border-muted-foreground/20 hover:border-green-200 bg-muted/20'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`flex size-8 items-center justify-center rounded-lg ${gstFullMode ? 'bg-green-500 text-white' : 'bg-muted text-muted-foreground'}`}>
                    <FileText className="size-4" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">GST Details (Full Mode)</p>
                    <p className="text-[11px] text-muted-foreground">Tax Invoice with GSTIN</p>
                  </div>
                </div>
                <Switch checked={gstFullMode} onCheckedChange={(v) => { setGstFullMode(v); if (v) { setGstSimpleMode(false); setGstEnabled(true); } }} />
              </div>
              {gstFullMode && (
                <div className="mt-2 flex flex-wrap gap-1">
                  <Badge className="bg-green-100 text-green-700 border-green-200 text-[10px]">GSTIN on Invoice</Badge>
                  <Badge className="bg-green-100 text-green-700 border-green-200 text-[10px]">Business Address</Badge>
                  <Badge className="bg-green-100 text-green-700 border-green-200 text-[10px]">State</Badge>
                </div>
              )}
            </div>

            {/* Simple Mode Card */}
            <div
              role="button"
              tabIndex={0}
              onClick={() => { setGstSimpleMode(!gstSimpleMode); if (!gstSimpleMode) setGstFullMode(false); if (!gstSimpleMode) setGstEnabled(true); }}
              onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); setGstSimpleMode(!gstSimpleMode); if (!gstSimpleMode) setGstFullMode(false); if (!gstSimpleMode) setGstEnabled(true); } }}
              className={`relative text-left rounded-xl border-2 p-4 transition-all duration-200 cursor-pointer ${
                gstSimpleMode
                  ? 'border-amber-400 bg-amber-50/60 dark:border-amber-600 dark:bg-amber-950/30 shadow-md shadow-amber-600/10'
                  : 'border-muted-foreground/20 hover:border-amber-200 bg-muted/20'
              }`}
            >
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  <div className={`flex size-8 items-center justify-center rounded-lg ${gstSimpleMode ? 'bg-amber-500 text-white' : 'bg-muted text-muted-foreground'}`}>
                    <Receipt className="size-4" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold">GST Only (Simple Mode)</p>
                    <p className="text-[11px] text-muted-foreground">GST amount only, no details</p>
                  </div>
                </div>
                <Switch checked={gstSimpleMode} onCheckedChange={(v) => { setGstSimpleMode(v); if (v) { setGstFullMode(false); setGstEnabled(true); } }} />
              </div>
              {gstSimpleMode && (
                <div className="mt-2 flex flex-wrap gap-1">
                  <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-[10px]">GST Amount Shown</Badge>
                  <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-[10px]">No GSTIN</Badge>
                  <Badge className="bg-amber-100 text-amber-700 border-amber-200 text-[10px]">No Address</Badge>
                </div>
              )}
            </div>
          </div>

          {/* Info Banner when neither mode selected */}
          {!gstFullMode && !gstSimpleMode && (
            <div className="rounded-lg bg-gray-50 dark:bg-gray-900/30 border border-dashed border-muted-foreground/25 p-3 text-center">
              <p className="text-xs text-muted-foreground">⚠️ No GST mode selected — GST will not be applied to invoices</p>
            </div>
          )}

          {/* ── GST Rate (shared by both modes) ── */}
          {(gstFullMode || gstSimpleMode) && (
            <div className="rounded-lg border bg-muted/30 p-4 space-y-3">
              <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">GST Rate</p>
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="grid gap-2">
                  <Label htmlFor="gst-rate">GST Rate (%)</Label>
                  <Input id="gst-rate" type="number" min="0" max="100" step="0.5" value={gstRate} onChange={(e) => setGstRate(parseFloat(e.target.value) || 0)} className={INPUT_CLS} />
                </div>
                <div className="flex items-end">
                  <div className="rounded-lg border bg-white dark:bg-gray-900 p-3 w-full">
                    <p className="text-xs text-muted-foreground mb-1">Tax Split (CGST + SGST)</p>
                    <div className="flex items-center gap-2 text-sm font-medium">
                      <span className="text-green-600">CGST: {(gstRate / 2).toFixed(1)}%</span>
                      <span className="text-muted-foreground">+</span>
                      <span className="text-green-600">SGST: {(gstRate / 2).toFixed(1)}%</span>
                      <span className="text-muted-foreground">=</span>
                      <span className="font-bold text-green-700">{gstRate}%</span>
                    </div>
                  </div>
                </div>
              </div>
              <div className="flex flex-wrap gap-2">
                {[5, 12, 18, 28].map((rate) => (
                  <button key={rate} type="button" onClick={() => setGstRate(rate)}
                    className={`px-3 py-1.5 rounded-lg border text-sm font-medium transition-all ${
                      gstRate === rate
                        ? 'bg-green-600 text-white border-green-600'
                        : 'border-muted-foreground/20 text-muted-foreground hover:border-green-300 hover:bg-green-50'
                    }`}
                  >{rate}%</button>
                ))}
              </div>
            </div>
          )}

          {/* ── Full Mode: GST Details Fields ── */}
          {gstFullMode && (
            <div className="space-y-3">
              <p className="text-xs font-semibold text-green-600 uppercase tracking-wider flex items-center gap-1.5">
                <FileText className="size-3" />Full Mode — GST Invoice Details
              </p>
              <p className="text-[11px] text-muted-foreground -mt-2">These details will appear on every tax invoice when Full Mode is active</p>

              {/* GST Number */}
              <div className={`rounded-xl border-2 p-4 transition-all duration-200 ${gstNumber ? 'border-green-300 bg-green-50/50 dark:border-green-800 dark:bg-green-950/20' : 'border-dashed border-muted-foreground/30 hover:border-green-300 bg-muted/20'}`}>
                <div className="flex items-center justify-between mb-2">
                  <Label htmlFor="gst-number" className="text-sm font-semibold">GST Number (GSTIN)</Label>
                  {gstNumber && gstNumber.length === 15 && <Badge className="bg-green-100 text-green-700 border-green-200 gap-1 text-[10px]"><Check className="size-3" />Valid</Badge>}
                </div>
                <div className="flex gap-2">
                  <Input id="gst-number" placeholder="e.g. 22AAAAA0000A1Z5" value={gstNumber}
                    onChange={(e) => { const val = e.target.value.toUpperCase().replace(/[^A-Z0-9]/g, ''); setGstNumber(val); }}
                    maxLength={15} className={`flex-1 font-mono tracking-wider text-sm ${INPUT_CLS}`} />
                  {gstNumber && (
                    <Button variant="outline" size="sm" onClick={() => { setGstNumber(''); toast.info('GST number cleared'); }} className="text-xs shrink-0 gap-1"><X className="size-3" />Clear</Button>
                  )}
                </div>
                {gstNumber.length > 0 && gstNumber.length < 15 && (
                  <p className="text-xs text-amber-600 mt-2 flex items-center gap-1"><AlertTriangle className="size-3" />{gstNumber.length}/15 digits — {15 - gstNumber.length} more needed</p>
                )}
              </div>

              {/* State */}
              <div className="grid gap-2">
                <Label htmlFor="gst-state" className="text-sm font-medium">State</Label>
                <Input id="gst-state" placeholder="e.g. Maharashtra" value={gstState}
                  onChange={(e) => setGstState(e.target.value)} className={INPUT_CLS} />
                <p className="text-[11px] text-muted-foreground">Required for inter-state and intra-state GST classification</p>
              </div>

              {/* Info: Uses existing business info */}
              <div className="rounded-lg border border-green-200 bg-green-50/50 dark:border-green-800 dark:bg-green-950/20 p-3">
                <p className="text-xs font-medium text-green-700 dark:text-green-400 mb-1">ℹ️ Business Details on Invoice</p>
                <p className="text-[11px] text-green-600 dark:text-green-500">
                  Full Mode uses your <strong>Business Name</strong>, <strong>Address</strong>, and <strong>Phone</strong> from the Business Information section above. Make sure those are filled correctly.
                </p>
              </div>
            </div>
          )}

          {/* ── Simple Mode Info ── */}
          {gstSimpleMode && (
            <div className="rounded-lg border border-amber-200 bg-amber-50/50 dark:border-amber-800 dark:bg-amber-950/20 p-4">
              <div className="flex items-start gap-3">
                <div className="flex size-8 items-center justify-center rounded-lg bg-amber-100 dark:bg-amber-900/50 shrink-0 mt-0.5">
                  <Receipt className="size-4 text-amber-600 dark:text-amber-400" />
                </div>
                <div>
                  <p className="text-sm font-semibold text-amber-700 dark:text-amber-400">Simple Mode Active</p>
                  <p className="text-[11px] text-amber-600 dark:text-amber-500 mt-1">
                    Only GST percentage and amount will be shown on invoices. <strong>No GSTIN, address, state, or business details</strong> will be displayed. Suitable for businesses that don't need a formal tax invoice.
                  </p>
                </div>
              </div>
            </div>
          )}

          <SaveBtn
            section="gst"
            label="Save GST Settings"
            onClick={() => {
              // Mutually exclusive: full mode overrides simple mode
              const effectiveEnabled = gstFullMode || gstSimpleMode;
              saveApi('gst', {
                enableGst: effectiveEnabled,
                gstFullMode,
                gstSimpleMode,
                gstRate,
                gstNumber,
                gstState,
              });
            }}
            saving={savingSection}
            saved={savedSection}
          />
        </div>
      </Section>

      {/* Delivery */}
      <Section id="delivery" icon={<Receipt className="h-5 w-5" />} title="Delivery Charge" desc="Set the default delivery charge applied to orders" badge={<SavedBadge section="delivery" saved={savedSection} />}>
        <div className="space-y-4">
          <div className="grid gap-2 sm:max-w-xs border-l-2 border-l-green-400 pl-3">
            <Label htmlFor="delivery-amount">Default Delivery Charge (₹)</Label>
            <Input id="delivery-amount" type="number" min="0" step="1" value={deliveryCharge} onChange={(e) => setDeliveryCharge(parseFloat(e.target.value) || 0)} className={INPUT_CLS} />
            <p className="text-xs text-muted-foreground">Set to 0 for free delivery</p>
          </div>
          <SaveBtn section="delivery" label="Save Delivery Charge" onClick={() => saveApi('delivery', { deliveryCharge })} saving={savingSection} saved={savedSection} />
        </div>
      </Section>

      {/* ═══ Thermal Printer Settings ═══ */}
      <Divider icon={<Printer className="size-3" />} label="Printing" />

      <Section id="printer" icon={<Printer className="h-5 w-5" />} title="Thermal Printer Settings" desc="Configure receipt printing — settings apply to all bill prints & reprints" open={true}
        badge={thermalSaved ? <Badge className="bg-green-100 text-green-700 border-green-200 text-[10px] gap-0.5"><Check className="size-3" />Saved</Badge> : undefined}>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="space-y-5">
            {/* ── Text Settings Card ── */}
            <div className="rounded-xl border bg-card p-4 space-y-4">
              <h4 className="text-sm font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
                <Printer className="size-4" />Text Settings
              </h4>

              {/* Font Size Slider */}
              <div className="grid gap-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm">Font Size</Label>
                  <Badge variant="outline" className="font-mono text-xs">{thermal.fontSize}px</Badge>
                </div>
                <input
                  type="range" min="8" max="18" step="1" value={thermal.fontSize}
                  onChange={(e) => patch({ fontSize: parseInt(e.target.value) })}
                  className="w-full h-2 rounded-lg appearance-none cursor-pointer accent-emerald-600 bg-muted"
                />
                <div className="flex justify-between text-[10px] text-muted-foreground"><span>8px</span><span>18px</span></div>
              </div>

              {/* Line Height Slider */}
              <div className="grid gap-2">
                <div className="flex items-center justify-between">
                  <Label className="text-sm">Line Height</Label>
                  <Badge variant="outline" className="font-mono text-xs">{thermal.lineHeight.toFixed(1)}x</Badge>
                </div>
                <input
                  type="range" min="1.0" max="2.0" step="0.1" value={thermal.lineHeight}
                  onChange={(e) => patch({ lineHeight: parseFloat(e.target.value) })}
                  className="w-full h-2 rounded-lg appearance-none cursor-pointer accent-emerald-600 bg-muted"
                />
                <div className="flex justify-between text-[10px] text-muted-foreground"><span>1.0</span><span>2.0</span></div>
              </div>

              {/* Text Weight */}
              <div className="grid gap-2">
                <Label className="text-sm">Text Weight</Label>
                <div className="flex gap-3">
                  {(['Light', 'Normal', 'Bold'] as const).map((w) => (
                    <label key={w} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border cursor-pointer transition-all text-sm ${
                      thermal.textWeight === w ? 'bg-emerald-600 text-white border-emerald-600 font-semibold' : 'border-muted hover:bg-muted/50'
                    }`}>
                      <input
                        type="radio" name="textWeight" value={w}
                        checked={thermal.textWeight === w}
                        onChange={() => patch({ textWeight: w })}
                        className="sr-only"
                      />
                      {w}
                    </label>
                  ))}
                </div>
              </div>

              {/* DPI Resolution */}
              <div className="grid gap-2">
                <Label className="text-sm">DPI Resolution</Label>
                <div className="flex gap-3">
                  {([203, 300] as const).map((dpi) => (
                    <label key={dpi} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border cursor-pointer transition-all text-sm ${
                      thermal.printDpi === dpi ? 'bg-emerald-600 text-white border-emerald-600 font-semibold' : 'border-muted hover:bg-muted/50'
                    }`}>
                      <input
                        type="radio" name="dpi" value={dpi}
                        checked={thermal.printDpi === dpi}
                        onChange={() => patch({ printDpi: dpi })}
                        className="sr-only"
                      />
                      {dpi} DPI{dpi === 300 ? ' (High)' : ''}
                    </label>
                  ))}
                </div>
              </div>

              {/* Paper Width */}
              <div className="grid gap-2">
                <Label className="text-sm">Paper Width</Label>
                <div className="flex gap-3">
                  {(['58mm', '80mm'] as const).map((pw) => (
                    <label key={pw} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border cursor-pointer transition-all text-sm ${
                      thermal.paperWidth === pw ? 'bg-emerald-600 text-white border-emerald-600 font-semibold' : 'border-muted hover:bg-muted/50'
                    }`}>
                      <input
                        type="radio" name="paperWidth" value={pw}
                        checked={thermal.paperWidth === pw}
                        onChange={() => patch({ paperWidth: pw })}
                        className="sr-only"
                      />
                      {pw}
                    </label>
                  ))}
                </div>
              </div>
            </div>

            {/* ── Squeeze Print Card ── */}
            <div className="rounded-xl border bg-card p-4 space-y-4">
              <h4 className="text-sm font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
                <Printer className="size-4" />Squeeze Print
              </h4>

              {/* Print Quality */}
              <div className="grid gap-2">
                <Label className="text-sm">Print Quality</Label>
                <div className="flex gap-3">
                  {(['Dark', 'Light'] as const).map((q) => (
                    <label key={q} className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg border cursor-pointer transition-all text-sm ${
                      thermal.printQuality === q ? 'bg-emerald-600 text-white border-emerald-600 font-semibold' : 'border-muted hover:bg-muted/50'
                    }`}>
                      <input
                        type="radio" name="printQuality" value={q}
                        checked={thermal.printQuality === q}
                        onChange={() => patch({ printQuality: q })}
                        className="sr-only"
                      />
                      {q}
                    </label>
                  ))}
                </div>
              </div>

              {/* Dithering */}
              <div className="grid gap-2">
                <Label className="text-sm">Dithering</Label>
                <div className="flex flex-col gap-2">
                  {(['None', 'Black & White', 'Floyd Steinberg'] as const).map((d) => (
                    <label key={d} className={`flex items-center gap-2 px-3 py-2 rounded-lg border cursor-pointer transition-all text-sm ${
                      thermal.dithering === d ? 'bg-emerald-600 text-white border-emerald-600 font-semibold' : 'border-muted hover:bg-muted/50'
                    }`}>
                      <input
                        type="radio" name="dithering" value={d}
                        checked={thermal.dithering === d}
                        onChange={() => patch({ dithering: d })}
                        className="sr-only"
                      />
                      {d}
                    </label>
                  ))}
                </div>
              </div>
            </div>

            {/* ── Logo Section ── */}
            <div className="rounded-xl border bg-card p-4 space-y-3">
              <h4 className="text-sm font-semibold text-emerald-700 dark:text-emerald-400 flex items-center gap-2">
                <ImageIcon className="size-4" />Receipt Logo
              </h4>
              <div className="flex items-center justify-between rounded-lg border p-3">
                <div>
                  <p className="text-sm font-medium">Show Logo on Receipt</p>
                  <p className="text-[11px] text-muted-foreground">Logo displays at top with full width</p>
                </div>
                <Switch
                  checked={thermal.showLogo}
                  onCheckedChange={(checked) => patch({ showLogo: checked })}
                  aria-label="Toggle receipt logo"
                />
              </div>
              {thermal.showLogo && (
                <div className="space-y-3">
                  <input
                    ref={logoInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (!file) return;
                      if (file.size > 200 * 1024) {
                        toast.error('Logo too large', { description: 'Maximum 200KB' });
                        if (logoInputRef.current) logoInputRef.current.value = '';
                        return;
                      }
                      const reader = new FileReader();
                      reader.onload = (ev) => {
                        const img = new Image();
                        img.onload = () => {
                          const canvas = document.createElement('canvas');
                          const MAX_W = 280, MAX_H = 80;
                          let w = img.width, h = img.height;
                          if (w > MAX_W) { h = (h * MAX_W) / w; w = MAX_W; }
                          if (h > MAX_H) { w = (w * MAX_H) / h; h = MAX_H; }
                          canvas.width = w; canvas.height = h;
                          canvas.getContext('2d')?.drawImage(img, 0, 0, w, h);
                          patch({ logo: canvas.toDataURL('image/png', 0.7) });
                          toast.success('Logo uploaded');
                        };
                        img.src = ev.target?.result as string;
                      };
                      reader.readAsDataURL(file);
                    }}
                  />
                  <div className="flex items-center gap-2">
                    <Button variant="outline" size="sm" onClick={() => logoInputRef.current?.click()} className="gap-1.5">
                      <Upload className="size-3.5" />{thermal.logo ? 'Change' : 'Upload'}
                    </Button>
                    {thermal.logo && (
                      <Button variant="ghost" size="sm" onClick={() => { patch({ logo: '' }); toast.info('Logo removed'); }}
                        className="gap-1.5 text-red-500 hover:text-red-600 hover:bg-red-50">
                        <Trash2 className="size-3.5" />Remove
                      </Button>
                    )}
                  </div>
                  {thermal.logo && (
                    <div className="flex justify-center rounded-lg border border-dashed bg-white p-2">
                      <img src={thermal.logo} alt="Logo" className="w-full max-w-[260px] max-h-[60px] object-contain" />
                    </div>
                  )}
                </div>
              )}
            </div>

            {/* Save / Reset */}
            <div className="flex flex-col gap-2 sm:flex-row sm:justify-end pt-2">
              <Button variant="outline" onClick={() => { setThermal(DEFAULT_THERMAL); toast.info('Thermal settings reset'); }} className="gap-1.5">
                <RotateCcw className="h-4 w-4" />Reset
              </Button>
              <Button
                onClick={async () => {
                  try {
                    setSavingSection('thermal');
                    const res = await fetch('/api/settings', {
                      method: 'PUT',
                      headers: { 'Content-Type': 'application/json' },
                      body: JSON.stringify({
                        section: 'thermal',
                        thermalPaperWidth: thermal.paperWidth,
                        thermalFontSize: thermal.fontSize,
                        thermalLineHeight: thermal.lineHeight,
                        thermalTextWeight: thermal.textWeight,
                        thermalDpi: thermal.printDpi,
                        thermalPrintQuality: thermal.printQuality,
                        thermalDithering: thermal.dithering,
                        thermalShowLogo: thermal.showLogo,
                        thermalLogo: thermal.logo,
                      }),
                    });
                    if (res.ok) {
                      localStorage.setItem('fp_thermal_settings', JSON.stringify(thermal));
                      setThermalSaved(true);
                      setSavedSection('thermal');
                      toast.success('Thermal settings saved');
                      setTimeout(() => { setThermalSaved(false); setSavedSection(null); }, 3000);
                    } else {
                      const err = await res.json().catch(() => ({}));
                      toast.error('Failed to save', { description: err.error || 'Unknown error' });
                    }
                  } catch { toast.error('Network error'); }
                  finally { setSavingSection(null); }
                }}
                disabled={savingSection === 'thermal'}
                className={`gap-1.5 transition-all ${thermalSaved ? 'bg-green-500 hover:bg-green-600' : 'bg-green-600 hover:bg-green-700'} text-white`}>
                {savingSection === 'thermal' ? <><Loader2 className="h-4 w-4 animate-spin" />Saving...</>
                  : thermalSaved ? <><Check className="h-4 w-4" />Saved!</>
                  : <><Save className="h-4 w-4" />Save Settings</>}
              </Button>
            </div>
          </div>
          {/* Preview */}
          <div className="flex flex-col items-center">
            <p className="text-xs font-semibold text-muted-foreground uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Receipt className="size-3.5" />Live Receipt Preview
            </p>
            <div className="bg-gray-50 dark:bg-gray-900/50 rounded-xl p-4 w-full flex justify-center">
              <ReceiptPreview shopName={shopName} shopAddress={address} shopPhone={phone} gstNumber={gstNumber} showGst={gstEnabled || gstFullMode || gstSimpleMode} t={thermal} />
            </div>
          </div>
        </div>
      </Section>

      {/* ═══ User Management ═══ */}
      {hasPermission('settings', 'userManagement') && (
        <>
          <Divider icon={<Users className="size-3" />} label="User Management" />
          <UserManagementSection />
        </>
      )}

      {/* ═══ Change Password ═══ */}
      <Divider icon={<Shield className="size-3" />} label="Account" />
      <ChangePasswordSection />

      {/* ═══ Data Management ═══ */}
      <Divider icon={<Database className="size-3" />} label="Data" />
      <div id="data-management">
        <Section id="data" icon={<Database className="h-5 w-5" />} title="Data Management" desc="Export, import, or reset all your business data" open={false}>
          <div className="space-y-4">
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between rounded-lg border p-4">
              <div><p className="text-sm font-medium flex items-center gap-2"><Download className="h-4 w-4 text-green-600" />Export All Data</p><p className="text-xs text-muted-foreground mt-0.5">Download a complete backup as JSON</p></div>
              <Button variant="outline" onClick={async () => { try { const r = await fetch('/api/data/export'); if (r.ok) { const b = new Blob([JSON.stringify(await r.json(), null, 2)], { type: 'application/json' }); const u = URL.createObjectURL(b); const a = document.createElement('a'); a.href = u; a.download = `eservices-data-${new Date().toISOString().split('T')[0]}.json`; a.click(); URL.revokeObjectURL(u); toast.success('Data exported successfully'); } else toast.error('Failed to export data'); } catch { toast.error('Failed to export data'); } }} className="w-full sm:w-auto gap-1.5"><Download className="h-4 w-4" />Export</Button>
            </div>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between rounded-lg border p-4">
              <div><p className="text-sm font-medium flex items-center gap-2"><Upload className="h-4 w-4 text-green-600" />Import Data</p><p className="text-xs text-muted-foreground mt-0.5">Restore from a previously exported JSON file</p></div>
              <Button variant="outline" onClick={() => importRef.current?.click()} className="w-full sm:w-auto gap-1.5"><Upload className="h-4 w-4" />Import</Button>
              <input ref={importRef} type="file" accept=".json" onChange={async (e) => { const f = e.target.files?.[0]; if (!f) return; try { const d = JSON.parse(await f.text()); const r = await fetch('/api/data/import', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(d) }); if (r.ok) { toast.success('Data imported successfully'); await fetchSettings(); } else toast.error('Failed to import data'); } catch { toast.error('Invalid JSON file'); } if (importRef.current) importRef.current.value = ''; }} className="hidden" />
            </div>
            <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between rounded-lg border border-red-200 dark:border-red-900/50 p-4">
              <div><p className="text-sm font-medium flex items-center gap-2 text-red-600 dark:text-red-400"><AlertTriangle className="h-4 w-4" />Reset System</p><p className="text-xs text-muted-foreground mt-0.5">Permanently delete all data — this cannot be undone</p></div>
              <AlertDialog open={resetOpen} onOpenChange={setResetOpen}>
                <AlertDialogTrigger asChild><Button variant="destructive" className="w-full sm:w-auto gap-1.5"><AlertTriangle className="h-4 w-4" />Reset</Button></AlertDialogTrigger>
                <AlertDialogContent><AlertDialogHeader><AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>This will permanently delete all your business data, bills, items, and settings. This action cannot be undone.</AlertDialogDescription></AlertDialogHeader>
                  <AlertDialogFooter><AlertDialogCancel>Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={async () => { setResetting(true); try { const r = await fetch('/api/data/reset', { method: 'POST' }); if (r.ok) { localStorage.removeItem('fp_thermal_settings'); setThermal(DEFAULT_THERMAL); toast.success('System reset successfully'); setResetOpen(false); await fetchSettings(); } else toast.error('Failed to reset system'); } catch { toast.error('Failed to reset system'); } finally { setResetting(false); } }} disabled={resetting} className="bg-destructive text-white hover:bg-destructive/90">
                      {resetting ? <><Loader2 className="h-4 w-4 animate-spin mr-1.5" />Resetting…</> : 'Yes, reset everything'}
                    </AlertDialogAction></AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </div>
        </Section>
      </div>

      {/* ═══ END ═══ */}
    </div>
  );
}
