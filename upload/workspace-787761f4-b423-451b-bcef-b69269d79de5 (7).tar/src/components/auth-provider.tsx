'use client';

import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';

export interface UserSession {
  unitCode: string;
  unitName: string;
  userId: string;
  loginId: string;
  name: string;
  role: string;
  permissions: Record<string, Record<string, boolean>>;
}

interface AuthContextType {
  isAuthenticated: boolean;
  currentUser: UserSession | null;
  token: string | null;
  login: (token: string, user: UserSession) => void;
  logout: () => void;
  switchUser: (token: string, user: UserSession) => void;
  hasPermission: (module: string, action: string) => boolean;
  isAdmin: boolean;
  refreshSession: () => Promise<boolean>;
}

const AuthContext = createContext<AuthContextType>({
  isAuthenticated: false,
  currentUser: null,
  token: null,
  login: () => {},
  logout: () => {},
  switchUser: () => {},
  hasPermission: () => false,
  isAdmin: false,
  refreshSession: async () => false,
});

export function useAuth() {
  return useContext(AuthContext);
}

const SESSION_KEY = 'eservices_session';
const ORIGINAL_SESSION_KEY = 'eservices_original_session';

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [currentUser, setCurrentUser] = useState<UserSession | null>(null);
  const [token, setToken] = useState<string | null>(null);

  const isAuthenticated = currentUser !== null;
  const isAdmin = currentUser?.role === 'Admin';

  // Helper: persist session to sessionStorage
  const persistSession = useCallback((tok: string, user: UserSession) => {
    try {
      const existing = sessionStorage.getItem(SESSION_KEY);
      let loginTime: string;
      try {
        const parsed = JSON.parse(existing || '{}');
        loginTime = parsed.loginTime || new Date().toISOString();
      } catch {
        loginTime = new Date().toISOString();
      }
      sessionStorage.setItem(SESSION_KEY, JSON.stringify({
        token: tok,
        user,
        loginTime,
      }));
    } catch {
      // sessionStorage unavailable (private browsing, quota exceeded, etc.)
    }
  }, []);

  // Restore session on mount
  useEffect(() => {
    try {
      const stored = sessionStorage.getItem(SESSION_KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed?.token && parsed?.user) {
          // Validate token with server AND fetch fresh permissions from DB
          fetch('/api/auth/session', {
            headers: { 'Authorization': `Bearer ${parsed.token}` },
          })
            .then(res => res.json())
            .then(data => {
              if (data.valid && data.user) {
                setToken(parsed.token);
                // Use fresh permissions from DB
                setCurrentUser(data.user);
                // Update sessionStorage with fresh permissions
                persistSession(parsed.token, data.user);
              } else {
                sessionStorage.removeItem(SESSION_KEY);
              }
            })
            .catch(() => {
              // Keep session if server unreachable
              setToken(parsed.token);
              setCurrentUser(parsed.user);
            });
        }
      }
    } catch {
      // invalid session
    }
  }, [persistSession]);

  const login = useCallback((newToken: string, user: UserSession) => {
    persistSession(newToken, user);
    setToken(newToken);
    setCurrentUser(user);
  }, [persistSession]);

  const switchUser = useCallback((newToken: string, user: UserSession) => {
    try {
      // Save original admin session for reference
      const currentSession = sessionStorage.getItem(SESSION_KEY);
      if (currentSession) {
        try {
          const parsed = JSON.parse(currentSession);
          sessionStorage.setItem(ORIGINAL_SESSION_KEY, JSON.stringify({
            token: parsed.token,
            user: parsed.user,
            loginTime: parsed.loginTime,
          }));
        } catch {
          // ignore
        }
      }
      // Set new session
      sessionStorage.setItem(SESSION_KEY, JSON.stringify({
        token: newToken,
        user,
        loginTime: new Date().toISOString(),
        switchedFrom: true,
      }));
    } catch {
      // sessionStorage unavailable (private browsing, quota exceeded, etc.)
    }
    setToken(newToken);
    setCurrentUser(user);
  }, []);

  const logout = useCallback(() => {
    // Log logout to server (fire-and-forget)
    if (token) {
      fetch('/api/auth/logout', {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` },
      }).catch(() => {});
    }
    try {
      sessionStorage.removeItem(SESSION_KEY);
      sessionStorage.removeItem(ORIGINAL_SESSION_KEY);
    } catch {
      // sessionStorage unavailable
    }
    setToken(null);
    setCurrentUser(null);
  }, [token]);

  // Refresh session: fetch latest permissions from DB without re-login
  const refreshSession = useCallback(async (): Promise<boolean> => {
    if (!token || !currentUser) return false;
    try {
      const res = await fetch('/api/auth/session', {
        headers: { 'Authorization': `Bearer ${token}` },
      });
      if (res.ok) {
        const data = await res.json();
        if (data.valid && data.user) {
          setCurrentUser(data.user);
          persistSession(token, data.user);
          return true;
        } else {
          // Session invalid — force logout
          logout();
          return false;
        }
      }
      return false;
    } catch {
      return false;
    }
  }, [token, currentUser, persistSession, logout]);

  const hasPermission = useCallback((module: string, action: string): boolean => {
    if (!currentUser) return false;
    if (currentUser.role === 'Admin') return true;
    const mod = currentUser.permissions?.[module];
    if (!mod) return false;
    return mod[action] === true;
  }, [currentUser]);

  return (
    <AuthContext.Provider value={{ isAuthenticated, currentUser, token, login, logout, switchUser, hasPermission, isAdmin, refreshSession }}>
      {children}
    </AuthContext.Provider>
  );
}
