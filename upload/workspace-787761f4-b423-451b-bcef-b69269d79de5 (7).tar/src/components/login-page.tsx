'use client';

import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import {
  Lock, Eye, EyeOff, Shield, Receipt, ArrowRight, Loader2,
  CheckCircle2, Keyboard, Sparkles, FileText, Printer,
  User, AlertCircle,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { toast } from 'sonner';
import type { UserSession } from './auth-provider';

interface LoginPageProps {
  onLoginSuccess: (token: string, user: UserSession) => void;
}

const PARTICLES = [
  { size: 4, color: '#34d399', opacity: 0.2, left: '6%', delay: '0s', duration: '16s' },
  { size: 6, color: '#2dd4bf', opacity: 0.15, left: '16%', delay: '-3s', duration: '20s' },
  { size: 3, color: '#4ade80', opacity: 0.25, left: '28%', delay: '-6s', duration: '14s' },
  { size: 8, color: '#a3e635', opacity: 0.1, left: '36%', delay: '-9s', duration: '22s' },
  { size: 5, color: '#34d399', opacity: 0.18, left: '48%', delay: '-2s', duration: '17s' },
  { size: 4, color: '#2dd4bf', opacity: 0.22, left: '58%', delay: '-11s', duration: '19s' },
  { size: 7, color: '#4ade80', opacity: 0.12, left: '68%', delay: '-5s', duration: '23s' },
  { size: 3, color: '#a3e635', opacity: 0.2, left: '78%', delay: '-8s', duration: '15s' },
  { size: 6, color: '#34d399', opacity: 0.14, left: '88%', delay: '-13s', duration: '21s' },
];

const FLOATING_ICONS = [
  { Icon: FileText, x: '10%', delay: '0s', duration: '20s', size: 22, opacity: 0.08 },
  { Icon: Receipt, x: '30%', delay: '-5s', duration: '24s', size: 26, opacity: 0.06 },
  { Icon: Printer, x: '55%', delay: '-10s', duration: '18s', size: 20, opacity: 0.07 },
  { Icon: FileText, x: '75%', delay: '-7s', duration: '22s', size: 24, opacity: 0.05 },
];

export default function LoginPage({ onLoginSuccess }: LoginPageProps) {
  const [userId, setUserId] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [shake, setShake] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [locked, setLocked] = useState(false);
  const [lockTimer, setLockTimer] = useState(0);
  const [successState, setSuccessState] = useState(false);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [mounted, setMounted] = useState(false);
  const [focusedField, setFocusedField] = useState<string | null>(null);
  const [showEnterHint, setShowEnterHint] = useState(false);

  const userIdRef = useRef<HTMLInputElement>(null);
  const passRef = useRef<HTMLInputElement>(null);

  useEffect(() => { setMounted(true); }, []);
  useEffect(() => {
    if (mounted) {
      const timer = setTimeout(() => userIdRef.current?.focus(), 600);
      return () => clearTimeout(timer);
    }
  }, [mounted]);
  useEffect(() => {
    const interval = setInterval(() => setCurrentTime(new Date()), 1000);
    return () => clearInterval(interval);
  }, []);
  useEffect(() => {
    if (lockTimer > 0) {
      const timer = setTimeout(() => setLockTimer((prev) => prev - 1), 1000);
      return () => clearTimeout(timer);
    } else if (locked) {
      setLocked(false);
      setAttempts(0);
    }
  }, [lockTimer, locked]);
  useEffect(() => {
    const timer = setTimeout(() => setShowEnterHint(true), 3000);
    return () => clearTimeout(timer);
  }, []);

  const greeting = useMemo(() => {
    const h = currentTime.getHours();
    if (h < 12) return 'Good Morning';
    if (h < 17) return 'Good Afternoon';
    return 'Good Evening';
  }, [currentTime]);

  const timeStr = currentTime.toLocaleTimeString('en-US', {
    hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true,
  });

  const dateStr = currentTime.toLocaleDateString('en-US', {
    weekday: 'long', month: 'long', day: 'numeric', year: 'numeric',
  });

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (locked) {
      toast.error(`Locked. Try again in ${lockTimer}s`);
      return;
    }
    if (!userId.trim() || !password.trim()) {
      toast.error('All fields are required');
      return;
    }
    setLoading(true);
    try {
      // Retry up to 15 times with progressive backoff — handles server warm-up in sandbox
      let res: Response | null = null;
      let lastError: Error | null = null;
      const maxAttempts = 15;
      for (let attempt = 0; attempt < maxAttempts; attempt++) {
        try {
          res = await fetch('/api/auth', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              unitCode: 'MAIN',
              loginId: userId.trim(),
              password: password.trim(),
            }),
          });
          lastError = null;
          break;
        } catch (fetchErr) {
          lastError = fetchErr as Error;
          // Show starting message on first failure
          if (attempt === 0) {
            toast.info('Server is starting up... please wait', { duration: 8000 });
          }
          const delay = Math.min(2000 * (attempt + 1), 10000);
          await new Promise(r => setTimeout(r, delay));
        }
      }
      if (!res) {
        toast.error('Server is not responding. Please wait a moment and try again.');
        return;
      }
      const data = await res.json();
      if (res.ok && data.success) {
        setSuccessState(true);
        toast.success(`Welcome, ${data.user.name}!`);
        setTimeout(() => {
          try {
            onLoginSuccess(data.token, data.user);
          } catch (err) {
            console.error('Login success callback failed:', err);
            setSuccessState(false);
            toast.error('Failed to complete login. Please try again.');
          }
        }, 1200);
      } else {
        setShake(true);
        setTimeout(() => setShake(false), 600);
        const newAttempts = attempts + 1;
        setAttempts(newAttempts);
        if (newAttempts >= 5) {
          setLocked(true);
          setLockTimer(30);
          toast.error('Too many failed attempts. Locked for 30 seconds.');
        } else {
          toast.error(data.error || 'Login failed');
        }
      }
    } catch {
      toast.error('Something went wrong. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent, nextRef?: React.RefObject<HTMLInputElement | null>) => {
    if (e.key === 'Enter') {
      if (nextRef?.current) {
        nextRef.current.focus();
      }
    }
  };

  if (successState) {
    return (
      <div className="min-h-screen flex items-center justify-center relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-950 via-green-900 to-teal-950" />
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <div className="absolute -top-1/2 -left-1/4 w-[800px] h-[800px] rounded-full bg-emerald-500/10 login-mesh-1" />
          <div className="absolute -bottom-1/2 -right-1/4 w-[600px] h-[600px] rounded-full bg-teal-400/10 login-mesh-2" />
        </div>
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {PARTICLES.map((p, i) => (
            <div key={`s-${i}`} className="absolute rounded-full" style={{
              width: p.size, height: p.size, left: p.left, bottom: '-20px',
              backgroundColor: p.color, opacity: p.opacity,
              animation: `particle-rise ${p.duration} linear infinite`, animationDelay: p.delay,
            }} />
          ))}
        </div>
        <div className="relative z-10 flex flex-col items-center gap-6">
          <div className="relative">
            <div className="absolute inset-0 rounded-full bg-emerald-400/20 animate-ping" style={{ animationDuration: '2s' }} />
            <svg width="96" height="96" viewBox="0 0 96 96" fill="none">
              <circle cx="48" cy="48" r="42" stroke="oklch(0.75 0.15 155)" strokeWidth="3" className="login-success-circle" />
              <path d="M28 50L40 62L68 34" stroke="oklch(0.75 0.15 155)" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round" className="login-success-check" />
            </svg>
          </div>
          <div className="text-center animate-fade-in-up" style={{ animationDelay: '0.4s' }}>
            <h2 className="text-3xl font-bold text-white mb-2">Access Granted!</h2>
            <p className="text-emerald-200/60 text-sm">Loading your workspace...</p>
          </div>
          <div className="w-56 h-1.5 bg-white/10 rounded-full overflow-hidden">
            <div className="h-full bg-gradient-to-r from-emerald-400 to-teal-400 rounded-full login-progress-fill" />
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen flex relative overflow-hidden">
      {/* LEFT PANEL */}
      <div className="hidden lg:flex lg:w-[55%] xl:w-[60%] relative bg-gradient-to-br from-emerald-950 via-green-900 to-teal-950 overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute -top-1/3 -left-1/4 w-[800px] h-[800px] rounded-full bg-emerald-500/8 login-mesh-1" />
          <div className="absolute -bottom-1/3 -right-1/4 w-[700px] h-[700px] rounded-full bg-teal-400/8 login-mesh-2" />
        </div>
        <div className="absolute inset-0 opacity-[0.03]" style={{
          backgroundImage: `linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)`,
          backgroundSize: '60px 60px',
        }} />
        <div className="absolute inset-0 pointer-events-none">
          {FLOATING_ICONS.map((item, i) => (
            <div key={i} className="login-particle absolute text-white" style={{
              left: item.x, animationDuration: item.duration, animationDelay: item.delay, opacity: item.opacity,
            }}>
              <item.Icon size={item.size} />
            </div>
          ))}
        </div>
        <div className="absolute inset-0 pointer-events-none overflow-hidden">
          {PARTICLES.map((p, i) => (
            <div key={`dot-${i}`} className="absolute rounded-full" style={{
              width: p.size, height: p.size, left: p.left, bottom: '-20px',
              backgroundColor: p.color, opacity: p.opacity,
              animation: `particle-rise ${p.duration} linear infinite`, animationDelay: p.delay,
            }} />
          ))}
        </div>

        <div className="relative z-10 flex flex-col justify-between p-10 xl:p-14 w-full">
          <div className={mounted ? 'animate-fade-in-up' : 'opacity-0'}>
            <div className="flex items-center gap-3 mb-2">
              <div className="flex size-12 rounded-xl bg-white/10 border border-white/10 items-center justify-center backdrop-blur-sm">
                <Receipt className="size-6 text-white" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-white tracking-tight">Eservices</h1>
                <p className="text-emerald-300/60 text-xs font-medium tracking-wide uppercase">POS & Billing System</p>
              </div>
            </div>
          </div>

          <div className="flex-1 flex flex-col justify-center max-w-lg">
            <div className={`${mounted ? 'animate-fade-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.1s' }}>
              <div className="flex items-center gap-2 mb-6">
                <div className="size-2 rounded-full bg-emerald-400 login-pulse-dot" />
                {mounted ? (
                  <>
                    <span className="text-emerald-300/70 text-sm font-medium">{greeting}</span>
                    <span className="text-emerald-400/50 text-sm ml-1">|</span>
                    <span className="text-emerald-300/50 text-sm tabular-nums">{timeStr}</span>
                  </>
                ) : (
                  <span className="text-emerald-300/50 text-sm">Loading...</span>
                )}
              </div>

              <h2 className="text-4xl xl:text-5xl font-bold text-white leading-tight mb-4">
                <span className="block text-white/90">Smart</span>
                <span className="block mt-1" style={{
                  background: 'linear-gradient(135deg, #34d399, #6ee7b7, #5eead4)',
                  WebkitBackgroundClip: 'text', WebkitTextFillColor: 'transparent', backgroundClip: 'text',
                }}>
                  POS & Billing
                </span>
              </h2>
              <p className="text-emerald-100/50 text-base leading-relaxed max-w-md">
                Complete billing solution with inventory management, cash tracking,
                khata book, and professional invoice printing.
              </p>
            </div>

            <div className="mt-10 grid grid-cols-2 gap-3">
              {[
                { icon: Receipt, label: 'A4 & Thermal', desc: 'Professional invoices' },
                { icon: Shield, label: 'Secure Access', desc: 'Role-based control' },
                { icon: FileText, label: 'GST Ready', desc: 'Tax compliant bills' },
                { icon: Sparkles, label: 'All-in-One', desc: 'Inventory, cash & more' },
              ].map((feature, i) => (
                <div key={feature.label}
                  className={`${mounted ? 'animate-fade-in-up' : 'opacity-0'} login-feature-card flex items-center gap-3 px-4 py-3 rounded-xl bg-white/[0.04] border border-white/[0.06]`}
                  style={{ animationDelay: `${0.2 + i * 0.08}s` }}
                >
                  <div className="flex size-9 shrink-0 rounded-lg bg-white/[0.08] items-center justify-center">
                    <feature.icon className="size-4 text-emerald-300/80" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-white/90 text-sm font-medium truncate">{feature.label}</p>
                    <p className="text-emerald-200/40 text-xs truncate">{feature.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className={`${mounted ? 'animate-fade-in-up' : 'opacity-0'}`} style={{ animationDelay: '0.6s' }}>
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <Shield className="size-4 text-emerald-400/60" />
                <span className="text-emerald-200/40 text-xs">256-bit Encrypted</span>
              </div>
              <div className="flex items-center gap-2">
                <Sparkles className="size-4 text-emerald-400/60" />
                <span className="text-emerald-200/40 text-xs">v3.0 — Eservices POS</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* RIGHT PANEL — Login Form */}
      <div className="w-full lg:w-[45%] xl:w-[40%] relative bg-white dark:bg-gray-950 flex items-center justify-center p-6 sm:p-8 lg:p-12">
        <div className="absolute top-0 right-0 w-64 h-64 bg-gradient-to-bl from-emerald-50 to-transparent dark:from-emerald-950/20 dark:to-transparent rounded-bl-full pointer-events-none" />
        <div className="absolute bottom-0 left-0 w-48 h-48 bg-gradient-to-tr from-teal-50 to-transparent dark:from-teal-950/20 dark:to-transparent rounded-tr-full pointer-events-none" />

        <div className="absolute pointer-events-none rounded-full" style={{
          width: '400px', height: '400px',
          background: 'radial-gradient(circle, rgba(16,185,129,0.12) 0%, rgba(20,184,166,0.06) 40%, transparent 70%)',
          top: '50%', left: '50%', transform: 'translate(-50%, -50%)',
          animation: 'glow-pulse 4s ease-in-out infinite', filter: 'blur(40px)',
        }} />

        <div className="relative z-10 w-full max-w-[420px]">
          {/* Mobile Logo */}
          <div className={`lg:hidden flex flex-col items-center mb-8 ${mounted ? 'animate-fade-in-up' : 'opacity-0'}`}>
            <div className="flex size-16 rounded-2xl bg-gradient-to-br from-emerald-500 to-teal-600 items-center justify-center shadow-lg shadow-emerald-600/25 mb-3">
              <Receipt className="size-8 text-white" />
            </div>
            <h1 className="text-xl font-bold text-gray-900 dark:text-white">Eservices</h1>
            <p className="text-muted-foreground text-xs mt-0.5">POS & Billing System</p>
          </div>

          <div className={`${mounted ? 'animate-login-slide-up' : 'opacity-0'} ${shake ? 'login-shake' : ''}`} style={{ animationDelay: '0.15s' }}>
            <div className="animated-border rounded-2xl p-[2px]">
              <div className="rounded-[14px] bg-white dark:bg-gray-950 p-6 sm:p-8">
                {/* Header */}
                <div className="mb-6">
                  <div className="flex items-center gap-2 mb-3">
                    <div className="flex size-8 rounded-lg bg-emerald-100 dark:bg-emerald-900/40 items-center justify-center">
                      <Lock className="size-4 text-emerald-600 dark:text-emerald-400" />
                    </div>
                    <span className="text-xs font-semibold text-emerald-600 dark:text-emerald-400 uppercase tracking-wider">
                      Secure Login
                    </span>
                  </div>
                  <h2 className="text-2xl font-bold text-gray-900 dark:text-white mb-1">{mounted ? greeting : 'Welcome'}</h2>
                  <p className="text-muted-foreground text-sm">Enter your credentials to access the system</p>
                </div>

                {/* Clock */}
                <div className="flex items-center gap-3 mb-5 p-3 rounded-xl bg-gradient-to-r from-emerald-50/80 to-teal-50/80 dark:from-emerald-950/30 dark:to-teal-950/30 border border-emerald-100/60 dark:border-emerald-800/40">
                  <div className="flex size-10 rounded-lg bg-emerald-100 dark:bg-emerald-900/50 items-center justify-center">
                    <span className="text-lg font-bold text-emerald-700 dark:text-emerald-300 tabular-nums leading-none">
                      {mounted ? currentTime.getDate() : '--'}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-medium text-emerald-800 dark:text-emerald-300">{mounted ? dateStr : 'Loading...'}</p>
                    <p className="text-sm font-bold text-emerald-600 dark:text-emerald-400 tabular-nums">
                      {mounted ? timeStr : '--:--:-- --'}
                    </p>
                  </div>
                  <div className="w-2 h-2 rounded-full bg-emerald-500 login-pulse-dot" />
                </div>

                {locked ? (
                  <div className="text-center py-10">
                    <div className="relative inline-flex size-20 items-center justify-center rounded-full bg-red-50 dark:bg-red-950/30 mb-4">
                      <div className="absolute inset-0 rounded-full border-2 border-red-200 dark:border-red-800/50 animate-ping opacity-30" />
                      <Lock className="size-8 text-red-500" />
                    </div>
                    <h3 className="text-lg font-semibold text-gray-900 dark:text-white mb-1">Account Locked</h3>
                    <p className="text-sm text-muted-foreground mb-4">Too many failed login attempts</p>
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-red-50 dark:bg-red-950/30">
                      <div className="w-2 h-2 rounded-full bg-red-500 animate-pulse" />
                      <span className="text-xl font-bold text-red-500 tabular-nums">{lockTimer}s</span>
                    </div>
                  </div>
                ) : (
                  <form onSubmit={handleLogin} className="space-y-4">
                    {/* User ID */}
                    <div className="space-y-1.5">
                      <label htmlFor="loginId" className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                        <User className="size-3.5 text-muted-foreground" />
                        User ID
                      </label>
                      <div className={`relative rounded-xl border transition-all duration-300 ${
                        focusedField === 'userId'
                          ? 'border-emerald-400 dark:border-emerald-500 ring-[3px] ring-emerald-500/15 shadow-lg shadow-emerald-500/10'
                          : 'border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/50'
                      }`}>
                        <User className={`absolute left-4 top-1/2 -translate-y-1/2 size-[18px] transition-colors duration-200 ${
                          focusedField === 'userId' ? 'text-emerald-500' : 'text-muted-foreground'
                        }`} />
                        <Input
                          ref={userIdRef}
                          id="loginId"
                          type="text"
                          placeholder="Enter your User ID"
                          value={userId}
                          onChange={(e) => setUserId(e.target.value.toLowerCase())}
                          onFocus={() => setFocusedField('userId')}
                          onBlur={() => setFocusedField(null)}
                          onKeyDown={(e) => handleKeyDown(e, passRef)}
                          className="pl-12 pr-10 h-12 border-0 bg-transparent shadow-none focus-visible:ring-0 focus-visible:outline-none text-sm"
                          disabled={loading}
                          autoComplete="username"
                          maxLength={30}
                        />
                        {userId && (
                          <CheckCircle2 className="absolute right-3.5 top-1/2 -translate-y-1/2 size-4 text-emerald-500 animate-scale-in" />
                        )}
                      </div>
                    </div>

                    {/* Password */}
                    <div className="space-y-1.5">
                      <label htmlFor="password" className="text-sm font-medium text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                        <Lock className="size-3.5 text-muted-foreground" />
                        Password
                      </label>
                      <div className={`relative rounded-xl border transition-all duration-300 ${
                        focusedField === 'password'
                          ? 'border-emerald-400 dark:border-emerald-500 ring-[3px] ring-emerald-500/15 shadow-lg shadow-emerald-500/10'
                          : 'border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-800/50'
                      }`}>
                        <Lock className={`absolute left-4 top-1/2 -translate-y-1/2 size-[18px] transition-colors duration-200 ${
                          focusedField === 'password' ? 'text-emerald-500' : 'text-muted-foreground'
                        }`} />
                        <Input
                          ref={passRef}
                          id="password"
                          type={showPassword ? 'text' : 'password'}
                          placeholder="Enter your password"
                          value={password}
                          onChange={(e) => setPassword(e.target.value)}
                          onFocus={() => setFocusedField('password')}
                          onBlur={() => setFocusedField(null)}
                          className="pl-12 pr-12 h-12 border-0 bg-transparent shadow-none focus-visible:ring-0 focus-visible:outline-none text-sm tracking-wide"
                          disabled={loading}
                          autoComplete="current-password"
                        />
                        {password && (
                          <CheckCircle2 className="absolute right-11 top-1/2 -translate-y-1/2 size-4 text-emerald-500 animate-scale-in" />
                        )}
                        <button
                          type="button"
                          onClick={() => setShowPassword(!showPassword)}
                          className="absolute right-3.5 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-gray-700 dark:hover:text-gray-300 transition-colors p-0.5 rounded-md hover:bg-gray-100 dark:hover:bg-gray-800"
                          tabIndex={-1}
                          aria-label={showPassword ? 'Hide password' : 'Show password'}
                        >
                          {showPassword ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
                        </button>
                      </div>
                    </div>

                    {/* Attempt counter */}
                    {attempts > 0 && (
                      <div>
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-red-50/80 dark:bg-red-950/20 border border-red-100/60 dark:border-red-800/30 animate-scale-in">
                            <Lock className="size-3 text-red-500 shrink-0" />
                            <span className="text-xs text-red-600 dark:text-red-400 font-medium tabular-nums">
                              {attempts}/5 failed attempt{attempts > 1 ? 's' : ''}
                            </span>
                          </div>
                          <span className="text-[10px] text-red-500 font-medium tabular-nums">
                            {5 - attempts} remaining
                          </span>
                        </div>
                        <div className="h-1 bg-red-100 dark:bg-red-900/30 rounded-full overflow-hidden">
                          <div className="h-full bg-gradient-to-r from-red-400 to-red-500 rounded-full transition-all duration-500 ease-out"
                            style={{ width: `${(attempts / 5) * 100}%` }} />
                        </div>
                      </div>
                    )}

                    <div className="pt-1">
                      <Button
                        type="submit"
                        disabled={loading || !userId.trim() || !password.trim()}
                        className="w-full h-13 bg-gradient-to-r from-emerald-600 to-green-600 hover:from-emerald-700 hover:to-green-700 text-white font-semibold text-sm gap-2.5 transition-all duration-300 shadow-lg shadow-emerald-600/25 hover:shadow-xl hover:shadow-emerald-600/35 hover:-translate-y-0.5 active:translate-y-0 disabled:opacity-50 disabled:shadow-none disabled:hover:translate-y-0 rounded-xl"
                      >
                        {loading ? (
                          <><Loader2 className="size-5 animate-spin" /><span>Authenticating...</span></>
                        ) : (
                          <><span>Sign In</span><ArrowRight className="size-4" /></>
                        )}
                      </Button>
                    </div>

                    <div className="flex items-center justify-center gap-1.5 text-xs text-muted-foreground/60 transition-all duration-500"
                      style={{ opacity: showEnterHint ? 1 : 0, transform: showEnterHint ? 'translateY(0)' : 'translateY(4px)' }}>
                      <Keyboard className="size-3" />
                      <span>Press Enter to sign in</span>
                      <kbd className="inline-flex items-center px-1.5 py-0.5 rounded border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800 text-[10px] font-mono font-medium text-gray-500 dark:text-gray-400 ml-0.5">↵</kbd>
                    </div>
                  </form>
                )}

                <div className="mt-6 flex items-center justify-center gap-2 text-xs text-muted-foreground/50">
                  <div className="w-1.5 h-1.5 rounded-full bg-emerald-500/50" />
                  <span>Eservices v3.0</span>
                  <span className="text-muted-foreground/30">|</span>
                  <span>Secured</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <style dangerouslySetInnerHTML={{ __html: `
        @keyframes particle-rise {
          0% { transform: translateY(0) scale(1); }
          50% { opacity: 0.3; }
          100% { transform: translateY(-100vh) scale(0.5); opacity: 0; }
        }
        @keyframes glow-pulse {
          0%, 100% { transform: translate(-50%, -50%) scale(1); opacity: 1; }
          50% { transform: translate(-50%, -50%) scale(1.15); opacity: 0.7; }
        }
      ` }} />
    </div>
  );
}
