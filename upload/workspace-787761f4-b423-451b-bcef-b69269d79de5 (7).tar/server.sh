#!/bin/bash
cd /home/z/my-project
while true; do
  NODE_OPTIONS="--max-old-space-size=512" bun run dev 2>&1 | tee -a dev.log
  sleep 2
done
