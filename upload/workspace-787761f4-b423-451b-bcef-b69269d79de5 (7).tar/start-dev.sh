#!/bin/bash
cd /home/z/my-project
while true; do
  if ! (ss -tlnp | grep -q ":3000 "); then
    nohup bun run dev > dev.log 2>&1 &
    echo "[$(date +%H:%M:%S)] Started dev server on 3000"
  fi
  sleep 5
done
