import subprocess, time, os, signal

os.chdir("/home/z/my-project")
log = open("/home/z/my-project/keep-alive.log", "a")

while True:
    try:
        # Check if server is running
        result = subprocess.run(["pgrep", "-f", "next-server"], capture_output=True)
        if not result.stdout.strip():
            log.write(f"[{time.strftime('%H:%M:%S')}] Server not running, starting...\n")
            log.flush()
            env = os.environ.copy()
            env["NODE_OPTIONS"] = "--max-old-space-size=512"
            proc = subprocess.Popen(
                ["bun", "run", "dev"],
                stdout=open("/home/z/my-project/dev.log", "a"),
                stderr=subprocess.STDOUT,
                env=env,
                preexec_fn=os.setpgrp,
            )
            log.write(f"[{time.strftime('%H:%M:%S')}] Started PID {proc.pid}\n")
            log.flush()
            # Wait for initial compile
            time.sleep(15)
    except Exception as e:
        log.write(f"[{time.strftime('%H:%M:%S')}] Error: {e}\n")
        log.flush()
    time.sleep(5)
