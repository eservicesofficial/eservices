#!/bin/bash
cd /home/z/my-project
while true; do
  if ! ss -tlnp 2>/dev/null | grep -q ":3000 "; then
    npx next dev -p 3000 > dev.log 2>&1
    sleep 2
  fi
  sleep 3
done
