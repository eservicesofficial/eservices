#!/bin/bash
# Keep-alive script for the Next.js dev server
cd /home/z/my-project
while true; do
    if ! pgrep -f "next-server" > /dev/null 2>&1; then
        echo "$(date): Server not running, starting..." >> /home/z/my-project/server-restart.log
        bun run dev > /home/z/my-project/dev.log 2>&1 &
        sleep 5
    fi
    sleep 10
done
