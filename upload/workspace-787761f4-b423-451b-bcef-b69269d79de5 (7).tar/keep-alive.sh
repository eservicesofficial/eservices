#!/bin/bash
while true; do
    echo "Starting server at $(date)"
    node .next/standalone/server.js 2>&1 &
    SERVER_PID=$!
    echo "PID: $SERVER_PID"
    # Wait for process to die
    wait $SERVER_PID 2>/dev/null
    echo "Server died, restarting in 3s..."
    sleep 3
done
