#!/bin/bash
cd /home/z/my-project
while true; do
  # Check if port 3001 is alive
  if ! (ss -tlnp | grep -q ":3001 "); then
    NODE_ENV=production PORT=3001 HOSTNAME=0.0.0.0 DATABASE_URL="file:/home/z/my-project/db/custom.db" \
      nohup node .next/standalone/server.js > /dev/null 2>&1 &
    echo "[$(date +%H:%M:%S)] Restarted Next.js on 3001"
  fi
  
  # Check if port 3000 is alive  
  if ! (ss -tlnp | grep -q ":3000 "); then
    nohup python3 /home/z/my-project/reverse_proxy.py > /dev/null 2>&1 &
    echo "[$(date +%H:%M:%S)] Restarted proxy on 3000"
  fi
  
  sleep 5
done
