#!/usr/bin/env python3
"""Persistent dev server watchdog - restarts the server if it dies."""
import subprocess
import time
import os
import signal
import sys

os.chdir('/home/z/my-project')

def start_server():
    # Use setsid to create new process group
    proc = subprocess.Popen(
        ['setsid', 'bash', '-c', 'trap "" HUP TERM; exec bun run dev'],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        preexec_fn=os.setsid,
    )
    return proc

print("Persistent server watchdog starting...", flush=True)

while True:
    proc = start_server()
    print(f"Server started: PID={proc.pid}, Group={os.getpgid(proc.pid)}", flush=True)
    
    try:
        for line in proc.stdout:
            decoded = line.decode('utf-8', errors='replace').rstrip()
            if decoded:
                print(f"[DEV] {decoded}", flush=True)
    except:
        pass
    
    ret = proc.wait()
    print(f"Server exited: code={ret}. Restarting in 2s...", flush=True)
    time.sleep(2)
