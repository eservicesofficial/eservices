import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const db = new PrismaClient();

async function seed() {
  console.log('Seeding database...');

  // 1. Create MAIN unit if not exists
  let unit = await db.unit.findUnique({ where: { code: 'MAIN' } });
  if (!unit) {
    unit = await db.unit.create({
      data: {
        code: 'MAIN',
        name: 'Main Branch',
        description: 'Primary business location',
        address: '',
        phone: '',
        email: '',
        isActive: true,
      },
    });
    console.log('Created MAIN unit');
  } else {
    console.log('MAIN unit already exists');
  }

  // Default permissions for each role
  const adminPermissions = JSON.stringify({
    billing: { access: true, create: true, edit: true, delete: true },
    reports: { access: true, export: true },
    inventory: { access: true, create: true, edit: true, delete: true },
    cashManager: { access: true, create: true, edit: true, delete: true },
    khata: { access: true, create: true, edit: true, delete: true },
    staff: { access: true, create: true, edit: true, delete: true },
    calculator: { access: true },
    settings: { access: true, edit: true, userManagement: true },
    auditLogs: { access: true },
  });

  const managerPermissions = JSON.stringify({
    billing: { access: true, create: true, edit: true, delete: false },
    reports: { access: true, export: true },
    inventory: { access: true, create: true, edit: true, delete: false },
    cashManager: { access: true, create: true, edit: true, delete: false },
    khata: { access: true, create: true, edit: true, delete: false },
    staff: { access: true, create: true, edit: true, delete: false },
    calculator: { access: true },
    settings: { access: false, edit: false, userManagement: false },
    auditLogs: { access: true },
  });

  const staffPermissions = JSON.stringify({
    billing: { access: true, create: true, edit: false, delete: false },
    reports: { access: false, export: false },
    inventory: { access: true, create: false, edit: false, delete: false },
    cashManager: { access: false, create: false, edit: false, delete: false },
    khata: { access: true, create: true, edit: false, delete: false },
    staff: { access: false, create: false, edit: false, delete: false },
    calculator: { access: true },
    settings: { access: false, edit: false, userManagement: false },
    auditLogs: { access: false },
  });

  // 2. Create default Admin user
  const adminLoginId = 'admin';
  let adminUser = await db.user.findUnique({
    where: { unitCode_loginId: { unitCode: 'MAIN', loginId: adminLoginId } },
  });

  if (!adminUser) {
    const hashedPassword = await bcrypt.hash('741504', 12);
    adminUser = await db.user.create({
      data: {
        unitCode: 'MAIN',
        loginId: adminLoginId,
        password: hashedPassword,
        name: 'Admin',
        role: 'Admin',
        permissions: adminPermissions,
        isActive: true,
      },
    });
    console.log('Created Admin user (loginId: admin, password: 741504)');
  } else {
    console.log('Admin user already exists');
  }

  // 3. Create Manager user
  const managerLoginId = '0000';
  let managerUser = await db.user.findUnique({
    where: { unitCode_loginId: { unitCode: 'MAIN', loginId: managerLoginId } },
  });

  if (!managerUser) {
    const hashedPassword = await bcrypt.hash('0000', 12);
    managerUser = await db.user.create({
      data: {
        unitCode: 'MAIN',
        loginId: managerLoginId,
        password: hashedPassword,
        name: 'Manager',
        role: 'Manager',
        permissions: managerPermissions,
        isActive: true,
      },
    });
    console.log('Created Manager user (loginId: 0000, password: 0000)');
  } else {
    console.log('Manager user already exists');
  }

  // 4. Create Staff user
  const staffLoginId = 'staff1';
  let staffUser = await db.user.findUnique({
    where: { unitCode_loginId: { unitCode: 'MAIN', loginId: staffLoginId } },
  });

  if (!staffUser) {
    const hashedPassword = await bcrypt.hash('staff1', 12);
    staffUser = await db.user.create({
      data: {
        unitCode: 'MAIN',
        loginId: staffLoginId,
        password: hashedPassword,
        name: 'Staff One',
        role: 'Staff',
        permissions: staffPermissions,
        isActive: true,
      },
    });
    console.log('Created Staff user (loginId: staff1, password: staff1)');
  } else {
    console.log('Staff user already exists');
  }

  // 5. Create MAIN settings if not exists
  const settings = await db.settings.findUnique({ where: { unitCode: 'MAIN' } });
  if (!settings) {
    await db.settings.create({
      data: { unitCode: 'MAIN' },
    });
    console.log('Created MAIN settings');
  } else {
    console.log('MAIN settings already exist');
  }

  console.log('Seeding complete!');
}

seed()
  .catch(console.error)
  .finally(() => db.$disconnect());
