import subprocess
import time
import os
import sys
import signal

os.chdir('/home/z/my-project')

def start_server():
    env = {**os.environ, 'NODE_ENV': 'production'}
    proc = subprocess.Popen(
        ['node', '.next/standalone/server.js'],
        stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT,
        env=env,
    )
    return proc

def main():
    print("Watchdog starting...", flush=True)
    
    while True:
        proc = start_server()
        print(f"Server started: PID={proc.pid}", flush=True)
        
        # Read output line by line
        for line in proc.stdout:
            decoded = line.decode('utf-8', errors='replace').rstrip()
            print(decoded, flush=True)
        
        # Process exited
        ret = proc.wait()
        print(f"Server exited: code={ret}, restarting in 2s...", flush=True)
        time.sleep(2)

if __name__ == '__main__':
    main()
