#!/usr/bin/env python3
"""Reverse proxy: port 3000 -> port 3001. Handles static files and chunked responses."""

import http.server
import http.client
import io
import os

TARGET_HOST = "127.0.0.1"
TARGET_PORT = 3001

class ProxyHandler(http.server.BaseHTTPRequestHandler):
    def do_request(self, method):
        content_length = int(self.headers.get('Content-Length', 0))
        body = self.rfile.read(content_length) if content_length > 0 else None
        path = self.path

        try:
            conn = http.client.HTTPConnection(TARGET_HOST, TARGET_PORT, timeout=60)

            # Forward headers, skip hop-by-hop
            skip_req = {'host', 'connection', 'transfer-encoding', 'keep-alive'}
            headers = {}
            for key in self.headers:
                if key.lower() not in skip_req:
                    headers[key] = self.headers[key]

            conn.request(method, path, body=body, headers=headers)
            resp = conn.getresponse()

            self.send_response(resp.status)
            skip_resp = {'transfer-encoding', 'connection', 'keep-alive'}
            for key, val in resp.getheaders():
                if key.lower() not in skip_resp:
                    self.send_header(key, val)
            self.end_headers()

            # Stream response in chunks for proper handling of large/static files
            while True:
                chunk = resp.read(65536)
                if not chunk:
                    break
                self.wfile.write(chunk)
                self.wfile.flush()

            conn.close()
        except Exception as e:
            try:
                self.send_error(502, str(e))
            except:
                pass

    def do_GET(self): self.do_request('GET')
    def do_POST(self): self.do_request('POST')
    def do_PUT(self): self.do_request('PUT')
    def do_DELETE(self): self.do_request('DELETE')
    def do_PATCH(self): self.do_request('PATCH')
    def do_OPTIONS(self): self.do_request('OPTIONS')
    def do_HEAD(self): self.do_request('HEAD')

    def log_message(self, format, *args):
        pass

if __name__ == '__main__':
    server = http.server.HTTPServer(('0.0.0.0', 3000), ProxyHandler)
    print(f"Proxy: 0.0.0.0:3000 -> {TARGET_HOST}:{TARGET_PORT}", flush=True)
    server.serve_forever()
